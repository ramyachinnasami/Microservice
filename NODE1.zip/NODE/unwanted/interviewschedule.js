/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
const fs = require('fs');
const util = require('util');
const jwt_decode = require('jwt-decode');

const Cryptr = require('cryptr');
const utilities = require('./../helpers/commonFunctions');
const response = require('../../config/response');
const conf = require('./../../config');

const cryptr = new Cryptr(conf.get('url').encrytptionKey);

module.exports = {
  addInterviewSchedule,
  getInterviewSchedule,
  deleteScheduleInfo,
  editInterviewSchedule,
  singleInterviewSchudule,
  AssignInterviewSchedule
};

/**
 * Add Interview Schedule Information
 * @returns status message
 */
function addInterviewSchedule(req, res) {
  const scheduleInfo = req.swagger.params.body.value;

  db.task((t) => {
    // execute a chain of queries against the task context, and return the result:
    return t.any(`INSERT INTO interview_catalog.schedule_interview("scheduleDate", "scheduleFromTime", "scheduleToTime", "workflowId", "candidateId", "interviewer", "status") VALUES ('${scheduleInfo.scheduleDate}', '${scheduleInfo.scheduleFromTime}', '${scheduleInfo.scheduleToTime}', '${scheduleInfo.workflowId}', '${scheduleInfo.candidateId}', '${scheduleInfo.interviewer}', '1') RETURNING "scheduleId"`)
      .then((scheduleId) => {
        let scheduleInterviewer = '';
        if (scheduleInfo.interviewer != '') {
          for (const i in scheduleInfo.interviewer) {
            scheduleInterviewer += `(${scheduleId[0].scheduleId}, ${scheduleInfo.interviewer[i]},1),`;
          }
          scheduleInterviewer = scheduleInterviewer.slice(0, -1);
          return t.query(`INSERT INTO interview_catalog.assigned_interviewer("scheduleId","interviewerId","status") VALUES ${scheduleInterviewer}`)
            .then(() => {
              const returnData = { scheduleData: scheduleInfo, id: scheduleId[0].scheduleId, decline: 1 };
              return returnData;
            });
        }

        const returnData = { scheduleData: scheduleInfo, id: scheduleId[0].scheduleId, decline: 0 };
        return returnData;
      })
      .then((returnData) => {
        const datas = returnData.scheduleData;
        const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

        const mailData = {};
        mailData.declineoption = returnData.decline;
        mailData.temName = 'interview/InterviewScheduleTemplate';
        mailData.subject = 'Screener App - Interview Schedule';

        const date = new Date(datas.scheduleDate);
        const formatted_date = `${date.getFullYear()}-${months[date.getMonth()]}-${date.getDate() - 1}`;

        mailData.candidateScheduleDate = formatted_date;

        mailData.candidateScheduleFrom = formatAMPM(datas.scheduleFromTime);
        mailData.candidateScheduleTo = formatAMPM(datas.scheduleToTime);

        db.query(`SELECT "candidateFirstName", concat("candidateFirstName",' ',"candidateLastName") AS candidatefullname FROM candidate_catalog.candidate_details WHERE "candidateId" = ${datas.candidateId}`)
          .then((candiData) => {
            if (candiData) {
              mailData.candidateName = candiData[0].candidatefullname;

              let where = '';
              if (datas.interviewer != '') {
                const intervie = datas.interviewer;
                const interviewerId = intervie.join(', ');
                where = ` and "userId" IN(${interviewerId})  `;
              }
              db.query(`SELECT "name", "emailId", "userId" FROM master_catalog.user WHERE "status" = 1 and "role" = 2 ${where}`)
                .then((userData) => {
                  if (userData) {
                    userData.forEach((userKey, userValue) => {
                      mailData.emailId = userKey.emailId;
                      mailData.interviewerName = userKey.name;
                      // Accept and Decline URL
                      mailData.acceptURL = cryptr.encrypt(`${returnData.id}/${userKey.userId}/${datas.candidateId}/1`);
                      mailData.declineURL = cryptr.encrypt(`${returnData.id}/${userKey.userId}/${datas.candidateId}/2`);
                      utilities.sendEmail(mailData);
                    });
                  }
                });
            }
          });
        res.json(response.success('Interview Scheduled Successfully', {
          id: returnData.id
        }));
      });
  })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Change the Time Format to 12 with AM PM
 * @returns status time
 */
function formatAMPM(time) {
  // Check correct time format and split into components
  /* time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

              if (time.length > 1) { // If time format correct
                time = time.slice (1);  // Remove full string match value
                time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
                time[0] = +time[0] % 12 || 12; // Adjust hours
              }
              return time.join (''); // return adjusted time or original string */

  const tmpArr = time.split(':');


  let time12;
  if (+tmpArr[0] == 12) {
    if (tmpArr[1] != '00') {
      tmpArr[1] = tmpArr[1].slice(1);
    }
    time12 = `${tmpArr[0].slice(1)}:${tmpArr[1]} PM`;
  } else if (+tmpArr[0] == '00') {
    time12 = `12:${tmpArr[1]} AM`;
  } else if (+tmpArr[0] > 12) {
    const datefor = (+tmpArr[0] - 12) > 9 ? (+tmpArr[0] - 12) : `0${+tmpArr[0] - 12}`;
    time12 = `${datefor}:${tmpArr[1]} PM`;
  } else {
    const datefor1 = (+tmpArr[0]) > 9 ? (+tmpArr[0]) : `0${+tmpArr[0]}`;
    time12 = `${datefor1}:${tmpArr[1]} AM`;
  }
  return time12;
}

/**
 * update Interview Schedule Information
 * @returns status message
 */
function editInterviewSchedule(req, res) {
  const scheduleInfo = req.swagger.params.body.value;

  // eslint-disable-next-line arrow-body-style
  db.task((t) => {
    return t.any(`UPDATE interview_catalog.schedule_interview SET "scheduleDate" = '${scheduleInfo.scheduleDate}', "scheduleFromTime" = '${scheduleInfo.scheduleFromTime}', "scheduleToTime" = '${scheduleInfo.scheduleToTime}', "workflowId" = '${scheduleInfo.workflowId}', "candidateId" = '${scheduleInfo.candidateId}', "interviewer" = '${scheduleInfo.interviewer}' where "scheduleId" = '${scheduleInfo.scheduleId}' RETURNING "scheduleId" `)
      .then((scheduleId) => {
        db.query(`UPDATE candidate_catalog.candidate_details SET "candidateAcceptStatus" = 0, "candidateAcceptBy" = 0 WHERE "candidateId" = ${scheduleInfo.candidateId} `)
          .then(() => {});


        return t.query(`DELETE FROM interview_catalog.assigned_interviewer WHERE "scheduleId" = ${scheduleId[0].scheduleId}`)
          .then(() => {
            if (scheduleInfo.interviewer != '') {
              let updatescheduleInterviewer = '';
              for (const i in scheduleInfo.interviewer) {
                updatescheduleInterviewer += `(${scheduleId[0].scheduleId}, ${scheduleInfo.interviewer[i]},1),`;
              }
              updatescheduleInterviewer = updatescheduleInterviewer.slice(0, -1);
              return t.query(`INSERT INTO interview_catalog.assigned_interviewer("scheduleId","interviewerId","status") VALUES ${updatescheduleInterviewer}`)
                .then(() => {
                  const returnData = {
                    scheduleData: scheduleInfo,
                    id: scheduleId[0].scheduleId
                  };
                  return returnData;
                });
            }
            const returnData = {
              scheduleData: scheduleInfo
            };
            return returnData;
          });
      });
  })
    .then((returnData) => {
      const datas = returnData.scheduleData;
      const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

      const mailData = {};
      mailData.temName = 'interview/InterviewScheduleTemplate';
      mailData.subject = 'Screener App - Interview Schedule';

      const date = new Date(datas.scheduleDate);
      const formatted_date = `${date.getFullYear()}-${months[date.getMonth()]}-${date.getDate() - 1}`;

      mailData.candidateScheduleDate = formatted_date;

      mailData.candidateScheduleFrom = formatAMPM(datas.scheduleFromTime);
      mailData.candidateScheduleTo = formatAMPM(datas.scheduleToTime);

      db.query(`SELECT "candidateFirstName", concat("candidateFirstName",' ',"candidateLastName") AS candidatefullname FROM candidate_catalog.candidate_details WHERE "candidateId" = ${datas.candidateId}`)
        .then((candiData) => {
          if (candiData) {
            mailData.candidateName = candiData[0].candidatefullname;

            let where = '';
            if (datas.interviewer != '') {
              const intervie = datas.interviewer;
              const interviewerId = intervie.join(', ');
              where = ` and "userId" IN(${interviewerId})  `;
            }

            db.query(`SELECT "name", "emailId", "userId" FROM master_catalog.user WHERE "status" = 1 and "role" = 2 ${where}`)
              .then((userData) => {
                if (userData) {
                  userData.forEach((userKey, userValue) => {
                    mailData.emailId = userKey.emailId;
                    mailData.interviewerName = userKey.name;
                    // Accept and Decline URL
                    mailData.acceptURL = cryptr.encrypt(`${returnData.id}/${userKey.userId}/${datas.candidateId}/1`);
                    mailData.declineURL = cryptr.encrypt(`${returnData.id}/${userKey.userId}/${datas.candidateId}/2`);

                    utilities.sendEmail(mailData);
                  });
                }
              });
          }
        });

      res.json(response.success('Interview Schedule Updated Successfully', {
        id: returnData.id
      }));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
/**
 * fetch all Interview Schedule Information
 * @returns status message
 */
function getInterviewSchedule(req, res) {
  const pageCount = req.query.pagecount;
  const page = req.query.page;
  const sortColumn = req.query.sort_column;
  const sortOrder = req.query.sort_order;
  const filterValue = req.query.filter_value;

  let pagelimit = 0;
  if (pageCount != '' && pageCount != undefined) {
    pagelimit = (page - 1) * pageCount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';

  if (pageCount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pageCount} OFFSET ${pagelimit}`;
  }

  if ((sortColumn != '' && sortColumn != undefined) && (sortOrder != '' && sortOrder != undefined)) {
    orderby = ` ORDER BY "${sortColumn}" ${sortOrder}`;
  } else {
    orderby = ' ORDER BY "scheduleFromTime" DESC';
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (a."candidateId" ILIKE '%${filterValue}%' OR b."name" ILIKE '%${filterValue}%') `;
  }

  const finalQuery = `SELECT  b."name", a."scheduleId", a."candidateId", a."scheduleFromTime", a."scheduleToTime", a."workflowId", a."interviewer" FROM interview_catalog.schedule_interview AS a JOIN master_catalog.user AS b ON a."interviewer" = b."userId"  where a."status" = 1 and b."status" = 1   ${filter} ${orderby} ${limit} `;

  db.tx((t) => {
    t.batch([
      t.any(finalQuery),
      t.any('SELECT COUNT("scheduleId") FROM interview_catalog.schedule_interview where "status" = 1')
    ]);
  })
    .then((sourceData) => {
      const opt = {};
      opt.datas = sourceData[0];
      opt.total_count = sourceData[1][0].count;

      res.send(response.success('data refresh', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * delete Interview Schedule
 * @requires id schedule id
 * @returns status message
 */
function deleteScheduleInfo(req, res) {
  const { scheduleId } = req.query;
  // delete query
  db.query(`UPDATE interview_catalog.schedule_interview SET "status"= 0 WHERE "scheduleId" = ${scheduleId}`)
    .then(() => {
      res.send(response.success('Deleted successfully', []));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * get single candidate Information
 *  @param id  to get candidate information
 */
function singleInterviewSchudule(req, res) {
  const id = req.swagger.params.candidate_id.value;
  db.task((t) => {
    // fetch schedule information from schedule details
    return t.query(`select "scheduleId", "scheduleDate", "scheduleFromTime", "scheduleToTime", "workflowId" from interview_catalog.schedule_interview WHERE "status" = '1' AND "candidateId" = ${id} `)
      .then((scheduleInfo) => {
        // if exist then fetch assigned interview info details
        if (scheduleInfo.length > 0) {
          return t.any(`select "scheduleId","interviewerId" from interview_catalog.assigned_interviewer where "status" = 1 and "scheduleId" = ${scheduleInfo[0].scheduleId}`).then((interviewerInfo) => {
            if (interviewerInfo) {
              scheduleInfo[0].interviewer = [];
              interviewerInfo.forEach((key, value) => {
                scheduleInfo[0].interviewer.push(key.interviewerId);
              });
            }
            res.send(response.success('', scheduleInfo[0]));
          });
        }
        res.send(response.success('', scheduleInfo[0]));
      });
  }).catch((err) => {
    if (util.isError(err)) res.error('NotFoundError', err); // return 404
    else res.error('InternalServerError', err); // else 500
  });
}

/**
 * update Interview Schedule Information
 * @returns status message
 */
function AssignInterviewSchedule(req, res) {
  const scheduleInfo = req.swagger.params.body.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  const user_id = decoded.userId;
  const user_role = decoded.role;

  db.task((t) => {
    return t.any(`UPDATE interview_catalog.schedule_interview SET "interviewer" = '${scheduleInfo.interviewer}' where "scheduleId" = '${scheduleInfo.scheduleId}' RETURNING "scheduleId" `)
    // eslint-disable-next-line arrow-body-style
      .then((scheduleId) => {
        return t.query(`UPDATE interview_catalog.assigned_interviewer set "status" = 0 WHERE "scheduleId" = ${scheduleId[0].scheduleId}`)
          .then(() => {
            if (scheduleInfo.interviewer != '') {
              let updatescheduleInterviewer = '';
              for (const i in scheduleInfo.assignedinterviewers) {
                updatescheduleInterviewer += `(${scheduleId[0].scheduleId}, ${scheduleInfo.assignedinterviewers[i]},1),`;
              }
              updatescheduleInterviewer = updatescheduleInterviewer.slice(0, -1);
              return t.query(`INSERT INTO interview_catalog.assigned_interviewer("scheduleId","interviewerId","status") VALUES ${updatescheduleInterviewer}`)
                .then(() => {
                  if (scheduleInfo.interviewerReassign == 1) {
                    db.query(`UPDATE candidate_catalog.candidate_details SET "candidateAcceptStatus" = ${scheduleInfo.statusId}, "candidateAcceptBy" = ${user_id}, "candidateReassignFrom" = ${user_id}, "candidateReassignTo" = '${scheduleInfo.interviewer}' WHERE "candidateId" = ${scheduleInfo.candidateId} RETURNING "modifiedOn"`)
                      .then(() => {
                        db.query(`INSERT INTO interview_catalog.interviewer_reschedule_history("interHistoryCandidateId", "interHistoryScheduleId", "interHistoryInterviewerId", "interHistoryInterviewerTo") VALUES (${scheduleInfo.candidateId}, ${scheduleInfo.scheduleId}, ${user_id}, '${scheduleInfo.interviewer}') `)
                          .then(() => {
                            const returnData = { scheduleData: scheduleInfo };
                            return returnData;
                          });
                      });
                  } else {
                    const returnData = { scheduleData: scheduleInfo, id: scheduleId[0].scheduleId };
                    return returnData;
                  }
                });
            }
            const returnData = { scheduleData: scheduleInfo };
            return returnData;
          });
      });
  })
    .then(() => {
      res.json(response.success('Candidate Reassigned Successfully', []));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
