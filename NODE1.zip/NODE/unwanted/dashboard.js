const fs = require('fs');
const util = require('util');
const jwt_decode = require('jwt-decode');
const response = require('../../config/response');
const sqlQueries = require('./../../config/queries/sqlQueries');

module.exports = {
  getSelectedCandidates,
  getSourceCounts,
  getSingleresourceDetails,
  getclientlist,
  getCounts,
  getAllActivityLogDetails,
  getcardresourcedetails
};


/**
 * getSelectedCandidates Information
 *  @param pageCount  pagecount
 *  @param page  to dispaly page
 *  @param sortColumn  for sorting column
 *  @param sortOrder  for sorting order
 *  @param filterValue  for filter value
 */
function getSelectedCandidates(req, res) {
  const {
    pagecount,
    page,
    sort_column,
    sort_order
  } = req.query;
  const filterValue = req.query.filter_value;


  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const user_id = decoded.userId;
  const user_role = decoded.role;

  let pagelimit = 0;

  if (pagecount != '') {
    pagelimit = (page - 1) * pagecount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';
  let subQuery = '';
  let selectVal = '';
  let where = '';
  if (pagecount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pagecount} OFFSET ${pagelimit}`;
  }

  orderby = ' a."candidateId", b."scheduleDate" ';
  if ((sort_column != '' && sort_column != undefined) && (sort_order != '' && sort_order != undefined)) {
    orderby += `"${sort_column}" ${sort_order}`;
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (a."candidateFirstName" ILIKE '%${filterValue}%' OR CAST(b."scheduleDate" AS TEXT) ILIKE '%${filterValue}%' ) `;
  }

  subQuery = ' LEFT JOIN interview_catalog.schedule_interview AS b ON a."candidateId" = b."candidateId" ';
  subQuery += ' LEFT JOIN master_catalog."user" AS usr ON usr."userId" = a."candidateAcceptBy" ';
  // subQuery += ' LEFT JOIN customer_catalog.client_details AS clnt ON clnt."clientId" = a."customerId" ';

  selectVal = ' (CASE WHEN a."candidateAcceptStatus" = 2 THEN \'Selected\' END) AS candidateStatus ';

  where = ' and b."scheduleDate" >= current_date ';
  let dmrole = '';
  if (user_role == 2) {
    where += ` and a."candidateAcceptBy" = ${user_id} `;
  } else if (user_role == 4) {
    if (decoded.userTeam) {
      dmrole = `  OR a."candidateAcceptBy" = ANY (string_to_array('${decoded.userTeam}', ',')::int[])`;
    }
    where += ` and (a."candidateAcceptBy" = ${user_id} ${dmrole}) `;
  }

  const finalQuery = `SELECT DISTINCT on (a."candidateId") to_char(b."scheduleDate", 'DD-MM-YYYY') as "scheduledate", a."candidateId", a."candidateFirstName", concat("candidateFirstName",' ',"candidateLastName") AS candidatefullname, ${selectVal}, a."candidateAcceptStatus", usr."name" AS candidateAcceptBy FROM candidate_catalog.candidate_details AS a ${subQuery} where a."status" = 1 AND b."status" = 1 AND a."candidateAcceptStatus" = 2 ${where} ${filter} ORDER BY ${orderby} DESC ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.one(`SELECT COUNT(a."candidateId") FROM candidate_catalog.candidate_details AS a ${subQuery} where a."status" = 1 AND b."status" = 1 AND a."candidateAcceptStatus" = 2 ${where} `)
  ]))
    .then((sourceData) => {
      const opt = {};
      // opt.datas = sourceData[0];
      opt.total_count = sourceData[1].count;
      // res.send(response.success('Successfully Retrived Selected Candidate List', opt));
    })
    .catch((err) => {
      console.log(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getSourceCounts
 * Info: Based on the swagger.yaml file endpoint for
 *        /dashboard/source-counts
 *
 * The listed @params below will used for select query
 */
function getSourceCounts(req, res) {
  db.query('SELECT sum(case when "candidateSource" = 1 then 1 else 0 end) AS Referrer, sum(case when "candidateSource" = 2 then 1 else 0 end) AS Consultancy, sum(case when "candidateSource" = 3 then 1 else 0 end) AS Naukri , sum(case when "candidateSource" = 4 then 1 else 0 end) AS DSRC FROM candidate_catalog.candidate_details where "status" = 1 and "candidateAcceptStatus" = 2 ')
    .then((details) => {
      // var details = details[0].split(',').map(Number);

      // eslint-disable-next-line array-callback-return
      Object.keys(details[0]).map((el) => {
        details[0][el] = parseInt(details[0][el]);
      });

      res.send(response.success('Client Details', details[0]));
    }).catch((err) => {
      console.log(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: getSingleresourceDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /dashboard/singleresourcedetails
 *
 * The listed @params below will used for select query
 */
function getSingleresourceDetails(req, res) {
  const id = req.swagger.params.id.value;
  const open = `select "numberOfResources" as open from customer_catalog.requirement_details where "isActive" = true AND "clientId" = ${id}`;
  const selected = `select count("candidateId") as selected FROM candidate_catalog.candidate_details where "status" = 1 AND "customerId" = ${id} and "candidateAcceptStatus" = 2`;
  db.tx(t => t.batch([
    t.query(open),
    t.query(selected)
  ]))
    .then((output) => {
      const resp = {
        open: output[0][0].open,
        selected: parseInt(output[1][0].selected)
      };
      res.send(response.success('data fetched', resp));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: getclientlist
 * Info: Based on the swagger.yaml file endpoint for
 *        /dashboard/getclientlist
 *
 * The listed @params below will used for select query
 */
function getclientlist(req, res) {
  const query = `SELECT  DISTINCT cd."clientId", cd."clientName" FROM customer_catalog.client_details as cd
                    LEFT join customer_catalog.requirement_details as rd ON cd."clientId" = rd."clientId"
                    where cd."isActive" = true AND rd."isActive" = true AND rd."numberOfResources" > 0
                    ORDER BY cd."clientId"`;
  db.query(query)
    .then((result) => {
      res.send(response.success('data fetched', result));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

function getcardresourcedetails(req, res) {
  const filter = req.swagger.params.filter.value;
  const query = `SELECT  DISTINCT cd."clientId", cd."clientName" ,rd."numberOfResources" AS OPEN,
    DATE_PART('day', now() - cd."createdOn" ) AS days,
    (select count("candidateId") as selected FROM candidate_catalog.candidate_details where "status" = 1 AND "customerId" = cd."clientId" and "candidateAcceptStatus" IN (2,6,8)) AS selected
    FROM customer_catalog.client_details as cd
    LEFT join customer_catalog.requirement_details as rd ON cd."clientId" = rd."clientId"
    where cd."isActive" = true and cd."clientStatus" < 3 AND rd."isActive" = true AND rd."numberOfResources" > 0 and cd."clientName" Ilike '%${filter}%'
    ORDER BY cd."clientId"`;
  db.query(query)
    .then((result) => {
      res.send(response.success('data fetched', result));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getCounts
 * Info: Based on the swagger.yaml file endpoint for
 *        /dashboard/getcounts
 *
 * The listed @params below will used for select query
 */
function getCounts(req, res) {
  const open = 'select SUM(rd."numberOfResources") as open from customer_catalog.requirement_details AS rd join customer_catalog.client_details AS cd  ON rd."clientId" = cd."clientId" WHERE cd."isActive" = true and rd."isActive" = true and cd."clientStatus" < 3';
  const selected = 'select count("candidateId") as selected FROM candidate_catalog.candidate_details where "status" = 1 AND "candidateAcceptStatus" = 2';
  const scheduled = 'select count("scheduleId") as ScheduledInterviewCount from interview_catalog.schedule_interview where "status" = 1 AND "scheduleDate" = current_date';


  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  const user_id = decoded.userId;
  const user_role = decoded.role;
  let teamuser = '';
  let rolejoin = ` AND cd."candidateAcceptBy" = ${user_id} `;
  if (user_role == 4) {
    if (decoded.userTeam) {
      rolejoin = `AND (cd."candidateAcceptBy" = ${user_id} OR cd."candidateAcceptBy" = ANY (string_to_array('${decoded.userTeam}', ',')::int[]) ) `;
      const teamuser_list = JSON.parse(`[${decoded.userTeam}]`);
      teamuser_list.forEach((teamuserid) => {
        teamuser += `OR '${teamuserid}' = ANY (string_to_array("interviewer",',')) `;
      });
    }
  }
  const futireInterviews = `select count("scheduleId") as futireInterviews from interview_catalog.schedule_interview where "status" = 1 AND "scheduleDate" >= current_date and ('${user_id}' = ANY (string_to_array("interviewer",',')) OR  "interviewer" = '' ${teamuser})`;
  const todayAssignedForInterviewer = `select count(a."scheduleId") as todayassignedinterviewcount from interview_catalog.schedule_interview AS a JOIN candidate_catalog.candidate_details AS b ON a."candidateId" = b."candidateId" where a."status" = 1 AND b."status" = 1 AND b."candidateAcceptStatus" IN(0,1,10) AND "scheduleDate" = current_date and ('${user_id}' = ANY (string_to_array("interviewer",',')) OR  "interviewer" = '' ${teamuser})`;

  if (user_role == 2 || user_role == 4) {
    // total candidate selected by the interviewer
    const selectedByInterviewer = `select count(cd."candidateId") as selectedbyinterviewer FROM candidate_catalog.candidate_details AS cd where cd."status" = 1 AND cd."candidateAcceptStatus" = 2 ${rolejoin}`;

    const todaySelectedByInterviewer = `select count(cd."candidateId") as todaySelectedByInterviewer FROM candidate_catalog.candidate_details AS cd
        join   interview_catalog.schedule_interview AS si ON cd."candidateId" = si."candidateId"
        where cd."status" = 1 AND si."status" = 1
        AND cd."candidateAcceptStatus" = 2 ${rolejoin} AND si."scheduleDate" = current_date`;
    const selectedAndRejectedCounts = `select count(cd."candidateId") as selectedandrejectedbyinterviewer FROM candidate_catalog.candidate_details AS cd where cd."status" = 1 AND cd."candidateAcceptStatus" IN(2,3) ${rolejoin}`;
    // total interview taken by interviewer today
    const totalScreenedToday = `select count(cd."candidateId") as totalScreened FROM candidate_catalog.candidate_details AS cd
        join   interview_catalog.schedule_interview AS si ON cd."candidateId" = si."candidateId"
        where cd."status" = 1 AND  cd."candidateAcceptStatus" IN(2,3) ${rolejoin}
        AND si."scheduleDate" = current_date`;
    // overall the interviewer screend
    const overalScreened = `select count(cd."candidateId") as overalScreened FROM candidate_catalog.candidate_details AS cd join   interview_catalog.schedule_interview AS si ON cd."candidateId" = si."candidateId" where cd."status" = 1 AND si."status" = 1 AND  cd."candidateAcceptStatus" IN(2,3) ${rolejoin}`;

    const candidateAcceptedByInterviewerCount = sqlQueries.dashboard.counts.candidateAcceptedByInterviewerCount;
    const yetToAcceptCount = sqlQueries.dashboard.counts.yetToAcceptCount;
    const pendingCount = sqlQueries.dashboard.counts.pendingCount;
    const weeklyscheduledForInterviewer = sqlQueries.dashboard.counts.weeklyScheduledCount;

    db.tx(t => t.batch([
      t.query(open),
      t.query(selected),
      t.query(scheduled),
      t.query(futireInterviews),
      t.query(selectedByInterviewer),
      t.query(selectedAndRejectedCounts),
      t.query(todayAssignedForInterviewer),
      t.query(totalScreenedToday),
      t.query(todaySelectedByInterviewer),
      t.query(overalScreened),
      t.query(candidateAcceptedByInterviewerCount, user_id),
      t.query(yetToAcceptCount, user_id),
      t.query(pendingCount, user_id),
      t.query(weeklyscheduledForInterviewer, user_id)

    ]))
      .then((output) => {
        const futireinterviews = parseInt(output[3][0].futireinterviews);
        const SelectedAndRejectedCounts = parseInt(output[5][0].selectedandrejectedbyinterviewer);
        const SelectedByInterviewerCount = parseInt(output[4][0].selectedbyinterviewer);
        const ScheduledInterviewHasToBeTaken = (futireinterviews - SelectedAndRejectedCounts);
        const RemainingCandidates = (futireinterviews - SelectedByInterviewerCount);
        const todayassignedinterviewcount = parseInt(output[6][0].todayassignedinterviewcount);
        const totalScreenedToday = parseInt(output[7][0].totalscreened);
        const todaySelectedByInterviewer = parseInt(output[8][0].todayselectedbyinterviewer);
        const overalscreened = parseInt(output[9][0].overalscreened);
        const acceptedscheduleCount = parseInt(output[10][0].acceptedbyinterviewer);
        const YetToAcceptCount = parseInt(output[11][0].yettoaccept);
        const PendingCount = parseInt(output[12][0].pendingcount);
        const weeklyScheduledCount = parseInt(output[13][0].weeklyschedule);

        const resp = {
          Open: parseInt(output[0][0].open),
          Selected: parseInt(output[1][0].selected),
          ScheduledInterviewCount: parseInt(output[2][0].scheduledinterviewcount),
          futireinterviews,
          SelectedByInterviewer: SelectedByInterviewerCount,
          ScheduledInterviewHasToBeTaken,
          Remaining: RemainingCandidates,
          todayassignedinterviewcount,
          totalScreenedToday,
          todaySelectedByInterviewer,
          overalscreened,
          AcceptedScheduleCount: acceptedscheduleCount,
          YetToAcceptCount,
          PendingCount,
          weeklyScheduledCount
        };
        res.send(response.success('data fetched', resp));
      })
      .catch((err) => {
        console.info(err);
        if (util.isError(err)) res.error('NotFoundError', err); // return 404
        else res.error('InternalServerError', err); // else 500
      });
  } else {
    db.tx(t => t.batch([
      t.query(open),
      t.query(selected),
      t.query(scheduled)
    ]))
      .then((output) => {
        const resp = {
          Open: parseInt(output[0][0].open),
          Selected: parseInt(output[1][0].selected),
          ScheduledInterviewCount: parseInt(output[2][0].scheduledinterviewcount),
          Remaining: parseInt(output[0][0].open) - parseInt(output[1][0].selected)
        };
        res.send(response.success('data fetched', resp));
      })
      .catch((err) => {
        console.info(err);
        if (util.isError(err)) res.error('NotFoundError', err); // return 404
        else res.error('InternalServerError', err); // else 500
      });
  }
}

/**
 * Name: getAllActivityLogDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /dashboard/activitylog
 *
 * The listed @params below will used for select query
 */
function getAllActivityLogDetails(req, res) {
  const {
    pagecount,
    page,
    sort_column,
    sort_order
  } = req.query;
    // const filterValue = req.query.filter_value;

  let pagelimit = 0;

  if (pagecount != '') {
    pagelimit = (page - 1) * pagecount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  // let filter = '';
  const subQuery = '';
  const selectVal = '';

  if (pagecount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pagecount} OFFSET ${pagelimit}`;
  }

  if ((sort_column != '' && sort_column != undefined) && (sort_order != '' && sort_order != undefined)) {
    orderby += ` ORDER BY "${sort_column}" ${sort_order}`;
  }

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const user_id = decoded.userId;
  const user_role = decoded.role;

  let where = '';
  let dmrole = '';
  if (decoded.userTeam && user_role == 4) {
    dmrole = ` OR a."userId" = ANY( string_to_array('${decoded.userTeam}',',')::int[]) `;
  }
  if (user_role == 2 || user_role == 4) {
    where = ` AND a."auditSubCategoryId" IN(6,7,8,9,10) AND (a."userId" = ${user_id} ${dmrole}) `;
  }

  db.query(`SELECT a."logId", a."auditSubCategoryId", TO_CHAR(a."date",'hh:mi AM') AS time, to_char(a."date", 'DD-MM-YYYY') AS date, a."userId", a."modifiedFor", a."role", a."modifiedBy", b."auditSubCategoryId", b."auditMainCategoryId", b."auditSubCategoryDesc", c."auditMainCategoryId", c."auditMainCategoryDesc" FROM  public.audit_log as a JOIN public.audit_sub_category AS b ON a."auditSubCategoryId" = b."auditSubCategoryId" JOIN public.audit_main_category AS c ON b."auditMainCategoryId" = c."auditMainCategoryId" WHERE '1' ${where} ORDER BY a."logId" DESC`)
    .then((result) => {
      res.send(response.success('data fetched', result));
    })
    .catch((err) => {
      console.info(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
