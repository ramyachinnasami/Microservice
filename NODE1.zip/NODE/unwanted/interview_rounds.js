
const util = require('util');
const response = require('../../config/response');


module.exports = {
  getAllInterviewRounds,
  addInterviewRound,
  updateInterviewRound,
  deleteInterviewRound
};

/*
  Function: Select all Interview Rounds
  req: A handle to the request object
  res: A handle to the response object
*/
function getAllInterviewRounds(req, res) {
  const pageCount = req.swagger.params.pagecount.value;
  const page = req.swagger.params.page.value;
  const sortColumn = req.swagger.params.sort_column.value;
  const sortOrder = req.swagger.params.sort_order.value;
  const filterValue = req.swagger.params.filter_value.value;

  let pagelimit = 0;
  if (pageCount != '' && pageCount != undefined) {
    pagelimit = (page - 1) * pageCount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';

  if (pageCount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pageCount} OFFSET ${pagelimit}`;
  }

  if ((sortColumn != '' && sortColumn != undefined) && (sortOrder != '' && sortOrder != undefined)) {
    orderby = ` ORDER BY "${sortColumn}" ${sortOrder}`;
  } else {
    orderby = ' ORDER BY "interviewRoundId" DESC';
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND ("interviewRoundName" ILIKE '%${filterValue}%' ) `;
  }

  const finalQuery = `SELECT DISTINCT "interviewRoundId", "interviewRoundName", "status" FROM master_catalog.interview_round_details where "status" = 1 ${filter} ${orderby} ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.any(`SELECT COUNT("interviewRoundId") FROM master_catalog.interview_round_details where "status" = 1 ${filter}`)
  ]))
    .then((datasInterviewRound) => {
      const opt = {};
      opt.datas = datasInterviewRound[0];
      opt.total_count = datasInterviewRound[1][0].count;

      res.send(response.success('data refresh', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/*
    Function: Insert a Interview Round
    req: interviewRoundName is Required Field
    res: other Fields is optional (interviewRoundName)
  */
function addInterviewRound(req, res) {
  const { interview_round_name } = req.swagger.params.body.value;

  db.none('INSERT INTO master_catalog.interview_round_details("interviewRoundName", "status") VALUES($1, $2)', [interview_round_name, 1])
    .then(() => {
      res.send(response.success('Intervirew Round Data has been inserted successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/*
    * Function: Update a Intervirew Round
  */
function updateInterviewRound(req, res) {
  const { interview_round_id, interview_round_name } = req.swagger.params.body.value;

  db.query('UPDATE master_catalog.interview_round_details SET "interviewRoundName" = $1 WHERE "interviewRoundId" = $2', [interview_round_name, interview_round_id])
    .then(() => {
      res.send(response.success('Intervirew Round Data has been updated successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/*
    * Function: Delete a Intervirew Round
    * Param 1: interviewRoundId is Required Field
    * Delete (status=0) a Intervirew Round by Intervirew Round ID
  */
function deleteInterviewRound(req, res) {
  const interview_round_id = req.swagger.params.interview_round_id.value;

  db.query('UPDATE master_catalog.interview_round_details SET "status" = $1 WHERE "interviewRoundId" = $2', [0, interview_round_id])
    .then(() => {
      res.send(response.success('Deleted successfully', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
