
const util = require('util');
const jwt_decode = require('jwt-decode');
const response = require('../../config/response');
const sqlQueries = require('./../../config/queries/sqlQueries');


module.exports = {
  interviewScheduleLists,
  getTechStackList,
  getSubTechStackList,
  getQuestionList,
  saveQuestionRating,
  getQuestionDetailsCount,
  getCandidateId,
  getGenQuestionList,
  getCandidateSummary,
  getCandidateDetails,
  getGeneralQuestions,
  getOverallCandidateSummary,
  finishedInterview
};


/**
 * Name: interviewScheduleLists
 * Info: Based on the swagger.yaml file endpoint for
 *        /interview_schedule
 *
 * The listed @params below will used for select query
 */
function interviewScheduleLists(req, res) {
  // variables defined in the Swagger document can be referenced using req.swagger.params.{parameter_name}
  const pageCount = req.query.pagecount;
  const page = req.query.page;
  let sortColumn = req.query.sort_column;
  const sortOrder = req.query.sort_order;
  const filterValue = req.query.filter_value;
  const candidateStatus = req.query.candidateStatus;


  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  const user_id = decoded.userId;
  const user_role = decoded.role;

  let pagelimit = 0;
  if (pageCount != '' && pageCount != undefined) {
    pagelimit = (page - 1) * pageCount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';
  let subQuery = '';
  let where = '';
  let selectVal = '';
  let teamuser = '';

  if (pageCount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pageCount} OFFSET ${pagelimit}`;
  }

  if ((sortColumn != '' && sortColumn != undefined) && (sortOrder != '' && sortOrder != undefined)) {
    sortColumn = (sortColumn == 'schedulefromtime') ? 'scheduleFromTime' : sortColumn;
    orderby = ` ORDER BY "${sortColumn}" ${sortOrder}`;
  } else {
    orderby = ' ORDER BY a."scheduleFromTime" DESC';
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (b."candidateFirstName" ILIKE '%${filterValue}%' OR CAST("scheduleDate" AS TEXT) ILIKE '%${filterValue}%' OR w."workflowName" ILIKE '%${filterValue}%' OR usr."name" ILIKE '%${filterValue}%' OR clnt."clientName" ILIKE '%${filterValue}%' ) `;
  }

  subQuery = ' JOIN candidate_catalog.candidate_details AS b ON a."candidateId" = b."candidateId" ';
  subQuery += ' LEFT JOIN customer_catalog.client_details AS clnt ON clnt."clientId" = b."customerId" ';
  subQuery += ' LEFT JOIN master_catalog.workflow AS w ON a."workflowId" = w."workflowId" ';
  subQuery += ' LEFT JOIN master_catalog.user AS usr ON usr."userId" = b."candidateAcceptBy" ';

  where = ' and w."status" = 1 ';

  if (candidateStatus) {
    where += ` and (b."candidateAcceptStatus" IN(${candidateStatus}) )`;
  } else {
    // where += ` and a."scheduleDate" >= current_date `;
    where += ' and b."candidateAcceptStatus" < 2 ';
  }

  if (user_role == 2) {
    where += ` and ('${user_id}' = ANY (string_to_array(a."interviewer",',')) OR  a."interviewer" = '') `;
  } else if (user_role == 4) {
    if (decoded.userTeam) {
      const teamuser_list = JSON.parse(`[${decoded.userTeam}]`);
      teamuser_list.forEach((teamuserid) => {
        teamuser += `OR '${teamuserid}' = ANY (string_to_array(a."interviewer",',')) `;
      });
    }
    where += ` and ('${user_id}' = ANY (string_to_array(a."interviewer",',')) ${teamuser} OR  a."interviewer" = '' ) `;
  }

  selectVal = '(CASE  WHEN b."candidateAcceptStatus" = 11 THEN \'Cancelled\' WHEN b."candidateAcceptStatus" = 1 THEN \'Accepted\' WHEN b."candidateAcceptStatus" = 2 THEN \'Selected\'  WHEN b."candidateAcceptStatus" = 3 THEN \'Rejected\' WHEN b."candidateAcceptStatus" = 4 THEN \'Didn’t Pick\' WHEN b."candidateAcceptStatus" = 5 THEN \'Reschedule\' WHEN b."candidateAcceptStatus" = 6 THEN \'Selected\' WHEN b."candidateAcceptStatus" = 7 THEN \'Rejected\' WHEN b."candidateAcceptStatus" = 8 THEN \'Customer Selected\' WHEN b."candidateAcceptStatus" = 9 THEN \'Customer Rejected \' WHEN b."candidateAcceptStatus" = 10 THEN \'Reassigned\' ELSE \'Not Accepted\' END) AS candidatestatus ';
  // selectVal += `, (SELECT "clientName" FROM customer_catalog.client_details WHERE "isActive" = true and "clientId" = b."customerId") AS customername`;
  selectVal += `, (SELECT COUNT("historyId") FROM interview_catalog.interview_history WHERE "interviewerId" = ${user_id} and "candidateId" = b."candidateId") AS interviewcount`;

  const finalQuery = `SELECT a."candidateStatus", a."scheduleId", a."interviewer", TO_CHAR(a."scheduleDate" :: DATE, 'DD-MM-YYYY') AS scheduleDate, b."candidateAcceptStatus", TO_CHAR(a."scheduleFromTime",'hh:mi AM') AS schedulefromtime, TO_CHAR(a."scheduleToTime",'hh:mi AM') AS scheduletotime, a."workflowId", a."status", a."candidateId", b."candidateFirstName", concat(b."candidateFirstName",' ',b."candidateLastName") AS candidatefullname, b."candidateAcceptBy", usr."name", w."workflowName", clnt."clientName" AS customername, ${selectVal} FROM interview_catalog.schedule_interview AS a ${subQuery} where a."status" = 1 and b."status" = 1 ${where} ${filter} ${orderby} ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.any(`SELECT COUNT(a."scheduleId") FROM interview_catalog.schedule_interview AS a ${subQuery} where a."status" = 1 and b."status" = 1 ${where} ${filter}`)
  ]))
    .then((sourceData) => {
      const opt = {};
      opt.datas = sourceData[0];
      opt.total_count = sourceData[1][0].count;

      res.send(response.success('data refresh', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getTechStackList
 * Info: Based on the swagger.yaml file endpoint for
 *        /getTechStackList
 *
 * The listed @params below will used for select query
 */
function getTechStackList(req, res) {
  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  const user_id = decoded.userId;
  const user_role = decoded.role;

  let subQuery = '';

  subQuery = `, (SELECT count("historyId") FROM interview_catalog.interview_history WHERE "interviewerId" = ${user_id} and "stackId" = tech."stackId" ) AS stackCount `;

  db.any('SELECT "stackId", "stackName", "status", "parentId", "stackDescription" FROM master_catalog."technical_stack" as tech WHERE "status" = 1 and "parentId" = 0')
    .then((stackInfo) => {
      res.send(response.success('', stackInfo));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getSubTechStackList
 * Info: Based on the swagger.yaml file endpoint for
 *        /getSubTechStackList/{id}
 *
 * The listed @params below will used for select query
 */
function getSubTechStackList(req, res) {
  const id = req.swagger.params.id.value;

  db.any(`SELECT "subStackId", "subStackName", "status", "stackId", "subStackDescription" FROM master_catalog."sub_technical_stack" WHERE "status" = 1 and "stackId"='${id}'`)
    .then((stackInfo) => {
      res.send(response.success('', stackInfo));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getQuestionList
 * Info: Based on the swagger.yaml file endpoint for
 *        /getQuestionList
 *
 * The listed @params below will used for select query
 */
function getQuestionList(req, res) {
  const subStackId = req.swagger.params.substackid.value;
  const candidateID = req.swagger.params.candidateid.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const userid = decoded.userId;
  const user_role = decoded.role;


  let join = '';
  const where = '';

  // if (user_role == 2) {
  join += ` LEFT JOIN interview_catalog.interview_history AS his ON his."questionId" = qus."questionId" and his."candidateId" = ${candidateID} and his."interviewerId" = ${userid} `;
  // }

  db.any(`SELECT concat('ques', qus."questionId") AS reasonId, qus."questionId", qus."question", qus."status", qus."subStackId" as "parentId",  his."historyId", his."candidateId", his."interviewerId", his."ratings", his."date", his."comments", his."stackId", his."subStackId", his."questionType" FROM interview_catalog."interview_questions" AS qus ${join} WHERE qus."status" > 0 and qus."questionType" = 'stack' and qus."subStackId" = '${subStackId}' ${where} ORDER BY qus."question" ASC`)
    .then((stackInfo) => {
      res.send(response.success('', stackInfo));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getGenQuestionList
 * Info: Based on the swagger.yaml file endpoint for
 *        /getGenQuestionList
 *
 * The listed @params below will used for select query
 */

function getGenQuestionList(req, res) {
  const candidateID = req.swagger.params.candidateId.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const userid = decoded.userId;
  const user_role = decoded.role;

  let join = '';
  const where = '';

  join += ` LEFT JOIN interview_catalog.interview_history AS his ON his."questionId" = qus."questionId" and his."candidateId" = ${candidateID} and his."interviewerId" = ${userid}  `;

  db.any(`SELECT concat('ques', qus."questionId") AS reasonId, qus."questionId", qus."question", qus."status", qus."subStackId" as "parentId",  his."historyId", his."candidateId", his."interviewerId", his."ratings", his."date", his."comments", his."stackId", his."subStackId", his."questionType" FROM interview_catalog."interview_questions" AS qus ${join} WHERE qus."status" > 0 and qus."questionType" = 'general' ${where} ORDER BY qus."question" ASC`)
    .then((questionInfo) => {
      res.send(response.success('', questionInfo));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: saveQuestionRating
 * Info: Based on the swagger.yaml file endpoint for
 *        /saveQuestionRating
 *
 * The listed @params below will used for select query
 */
function saveQuestionRating(req, res) {
  const value = req.swagger.params.body.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  let successmessage = '';

  const user_id = decoded.userId;
  const user_role = decoded.role;
  if (value.questionType == 'stack') {
    successmessage = 'Rating Added Successfully';
  } else {
    successmessage = 'Comments Submitted Successfully';
  }
  let qs = '';

  db.any(`SELECT "candidateId", "interviewer" FROM interview_catalog."schedule_interview" WHERE "scheduleId" = '${value.scheduleId}'`)
    .then((stackInfo) => {
    // res.send(response.success("", stackInfo));
      db.any(`SELECT count(*) as getquestcount FROM interview_catalog."interview_history" WHERE "questionId"='${value.questId}' AND "candidateId"='${stackInfo[0].candidateId}'`)
        .then((questcount) => {
          if (questcount[0].getquestcount == 0) {
            qs = `INSERT INTO interview_catalog.interview_history("candidateId", "interviewerId", "questionId", "ratings", "comments","stackId","subStackId","questionType") VALUES ( '${stackInfo[0].candidateId}', '${user_id}', '${value.questId}','${value.rating}','${value.reason}','${value.stackId}','${value.subStackId}','${value.questionType}' )`;
          } else {
            qs = `UPDATE interview_catalog.interview_history SET  "ratings"='${value.rating}', "comments"='${value.reason}' WHERE "questionId"='${value.questId}' AND "candidateId"='${stackInfo[0].candidateId}';`;
          }

          db.query(qs).then((result) => {
            db.any(`SELECT SUM(Totalcount) Totalcount,SUM(WrongAns) WrongAns, SUM(RightAns) RightAns, SUM(ParthialyRightAns) ParthialyRightAns FROM (SELECT COUNT(*) as Totalcount,
            CASE
              WHEN ratings='2' THEN COUNT(ratings)
            END 
            AS WrongAns,
            CASE
              WHEN ratings='1' THEN COUNT(ratings)
            END 
            AS RightAns,
            CASE
              WHEN ratings='3' THEN COUNT(ratings)
            END 
            AS ParthialyRightAns
                FROM interview_catalog."interview_history" WHERE "questionType" = 'stack' and "candidateId"='${stackInfo[0].candidateId}' AND "ratings" > 0 GROUP BY "ratings") questioncount`).then((questionhistory) => {
              res.send(response.success(successmessage, questionhistory));
            });
          });
        }).catch((err) => {
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
        });
    });
}


/**
 * Name: getQuestionDetailsCount
 * Info: Based on the swagger.yaml file endpoint for
 *        /getQuestionDetailsCount/{id}
 *
 * The listed @params below will used for select query
 */
function getQuestionDetailsCount(req, res) {
  const id = req.swagger.params.id.value;
  db.any(`SELECT "candidateId", "interviewer"
  FROM interview_catalog."schedule_interview" WHERE "scheduleId"='${id}'`).then((stackInfo) => {
    // res.send(response.success("", stackInfo));
    db.any(`SELECT count(*) as getquestcount
      FROM interview_catalog."interview_history" WHERE "candidateId"='${stackInfo[0].candidateId}' AND "questionType"='stack'`).then((questcount) => {
      db.any(`SELECT SUM(Totalcount) Totalcount,SUM(WrongAns) WrongAns,SUM(RightAns) RightAns,SUM(ParthialyRightAns) ParthialyRightAns FROM (SELECT COUNT(*) as Totalcount,
        CASE
          WHEN ratings='2' THEN COUNT(ratings)
        END 
        AS WrongAns,
        CASE
          WHEN ratings='1' THEN COUNT(ratings)
        END 
        AS RightAns,
        CASE
          WHEN ratings='3' THEN COUNT(ratings)
        END 
        AS ParthialyRightAns
            FROM interview_catalog."interview_history" WHERE "questionType" = 'stack' AND "candidateId"='${stackInfo[0].candidateId}' AND "questionType"='stack' AND "ratings" >0 GROUP BY "ratings") questioncount`).then((questionhistory) => {
        res.send(response.success('', questionhistory));
      });
    });
  }).catch((err) => {
    if (util.isError(err)) res.error('NotFoundError', err); // return 404
    else res.error('InternalServerError', err); // else 500
  });
}


/**
 * Name: getCandidateSummary
 * Info: Based on the swagger.yaml file endpoint for
 *        /getCandidateSummary/{id}
 *
 * The listed @params below will used for select query
 */
function getCandidateSummary(req, res) {
  const id = req.swagger.params.id.value;
  const finalresponse = [];
  const ratingvalue = 0;
  const questcount = 0;
  const finalpercentage = 0;

  db.any(`SELECT ROUND(SUM(subq."ratingpercent")/SUM(subq.Totalcount),2) RatingPercent,(subq."subStackId") substackId,SUM(subq.Totalcount) questCount,string_agg(DISTINCT subq."stackName",',') StackName,string_agg(DISTINCT subq.subStackName,',') subStackName from (SELECT COUNT(*) as Totalcount,IH."historyId",IH."ratings",IH."stackId",IH."subStackId",TS."stackName",string_agg(STS."subStackName",',') Substackname,
        CASE
          WHEN IH."ratings"='2' THEN 0
          WHEN IH."ratings"='1' THEN 100
          WHEN IH."ratings"='3' THEN 50
        END
        AS Ratingpercent
           FROM interview_catalog."interview_history" IH LEFT JOIN master_catalog."technical_stack" TS ON IH."stackId"=TS."stackId" LEFT JOIN master_catalog."sub_technical_stack" STS ON IH."subStackId"=STS."subStackId" WHERE IH."questionType" = 'stack' AND "candidateId"='${id}' AND "questionType"='stack' AND "ratings" >0 GROUP BY IH."subStackId",IH."ratings",IH."stackId",IH."historyId",TS."stackName") subq GROUP BY subq."subStackId" `).then((questionhistory) => {
    res.send(response.success('', questionhistory));
  }).catch((err) => {
    if (util.isError(err)) res.error('NotFoundError', err); // return 404
    else res.error('InternalServerError', err); // else 500
  });
}


/**
 * Name: getOverallCandidateSummary
 * Info: Based on the swagger.yaml file endpoint for
 *        /getOverallCandidateSummary/{id}
 *
 * The listed @params below will used for select query
 */

function getOverallCandidateSummary(req, res) {
  const id = req.swagger.params.id.value;
  const finalresponse = [];
  const ratingvalue = 0;
  const questcount = 0;
  const finalpercentage = 0;

  db.any(`SELECT ROUND(SUM(subq."ratingpercent")/SUM(subq.Totalcount),2) RatingPercent,SUM(subq.Totalcount) questCount from (SELECT COUNT(*) as Totalcount,IH."historyId",IH."ratings",IH."stackId",IH."subStackId",TS."stackName",string_agg(STS."subStackName",',') Substackname,
      CASE
        WHEN IH."ratings"='2' THEN 0
        WHEN IH."ratings"='1' THEN 100
        WHEN IH."ratings"='3' THEN 50
      END
      AS Ratingpercent
      FROM interview_catalog."interview_history" IH LEFT JOIN master_catalog."technical_stack" TS ON IH."stackId"=TS."stackId" LEFT JOIN master_catalog."sub_technical_stack" STS ON IH."subStackId"=STS."subStackId" WHERE "questionType" = 'stack' AND "candidateId"='${id}' AND "questionType"='stack' AND "ratings" >0 GROUP BY IH."subStackId",IH."ratings",IH."stackId",IH."historyId",TS."stackName") subq `)
    .then((questionhistory) => {
      res.send(response.success('', questionhistory));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getCandidateId
 * Info: Based on the swagger.yaml file endpoint for
 *        /getCandidateId/{scheduleid}
 *
 * The listed @params below will used for select query
 */
function getCandidateId(req, res) {
  const id = req.swagger.params.scheduleid.value;

  db.any(`SELECT "candidateId", "interviewer", "scheduleId" FROM interview_catalog."schedule_interview" WHERE "scheduleId"='${id}'`)
    .then((stackInfo) => {
      // res.send(response.success("", stackInfo));
      res.send(response.success('', stackInfo));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getCandidateDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /getCandidateDetails/{id}
 *
 * The listed @params below will used for select query
 */

function getCandidateDetails(req, res) {
  const id = req.swagger.params.id.value;

  db.any(`SELECT candi."candidateId", candi."candidateFirstName", candi."candidateEmailId", candi."workExpYears", candi."workExpMonths", sin."scheduleId" FROM candidate_catalog.candidate_details AS candi JOIN interview_catalog."schedule_interview" AS sin ON sin."candidateId" = candi."candidateId" WHERE candi."candidateId"='${id}' `)
    .then((candidateInfo) => {
      res.send(response.success('', candidateInfo));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * get General Questions
 * @requires candidateId of the row to delte the Candidate Info
 * @returns general Questions
 */
function getGeneralQuestions(req, res) {
  const candidateId = req.swagger.params.candidateId.value;

  db.any(sqlQueries.interviewSchedule.toGetGenQues, candidateId)
    .then((generalQuestions) => {
      res.send(response.success('General questions Retrived Successfully .', generalQuestions));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: finishedInterview
 * Info: Based on the swagger.yaml file endpoint for
 *        /finishedinterview
 *
 * The listed @params below will used for select query
 */
function finishedInterview(req, res) {
  const scheduleInfo = req.swagger.params.body.value;

  db.any(`UPDATE interview_catalog.schedule_interview SET "candidateStatus" = '1' WHERE "scheduleId" = '${scheduleInfo.scheduleId}' RETURNING "scheduleId", "candidateId" `)
    .then((scheduleData) => {
      res.send(response.success('Finished interview', scheduleData));
    });
}
