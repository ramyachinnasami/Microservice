
const util = require('util');
const response = require('../../config/response');


module.exports = {
  sourceAllData,
  sourceAddData,
  sourceUpdate,
  sourceDelete,
  sourceById
};

/*
  Function: Select all Sources
  req: a handle to the request object
  res: a handle to the response object
*/
function sourceAllData(req, res) {
  const pageCount = req.swagger.params.pagecount.value;
  const page = req.swagger.params.page.value;
  const sortColumn = req.swagger.params.sort_column.value;
  const sortOrder = req.swagger.params.sort_order.value;
  const filterValue = req.swagger.params.filter_value.value;

  let pagelimit = 0;
  if (pageCount != '' && pageCount != undefined) {
    pagelimit = (page - 1) * pageCount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';

  if (pageCount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pageCount} OFFSET ${pagelimit}`;
  }

  if ((sortColumn != '' && sortColumn != undefined) && (sortOrder != '' && sortOrder != undefined)) {
    orderby = ` ORDER BY "${sortColumn}" ${sortOrder}`;
  } else {
    orderby = ' ORDER BY "sourceId" DESC';
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND ("sourceName" LIKE '%${filterValue}%' OR "address" LIKE '%${filterValue}%' OR CAST("contactNumber" AS TEXT) LIKE '%${filterValue}%') `;
  }

  const finalQuery = `SELECT DISTINCT "sourceId", "sourceName", "status", "contactNumber", "address" FROM master_catalog.source where "status" = 1 ${filter} ${orderby} ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.any(`SELECT COUNT("sourceId") FROM master_catalog.source where "status" = 1 ${filter}`)
  ]))
    .then((sourceData) => {
      const opt = {};
      opt.datas = sourceData[0];
      opt.total_count = sourceData[1][0].count;

      res.send(response.success('data refresh', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/*
    Function: Insert a Source
    req: sourcename is Required Field
    res: other Fields is optional (sourcephno, sourceaddress)
  */
function sourceAddData(req, res) {
  const { source_name, source_phone, source_address } = req.swagger.params.body.value;

  db.none('INSERT INTO master_catalog.source("sourceName", "status", "contactNumber", "address") VALUES($1, $2, $3, $4)', [source_name, 1, source_phone, source_address])
    .then(() => {
      res.send(response.success('Source Data has been inserted successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/*
    * Function: Update a Source
  */
function sourceUpdate(req, res) {
  const {
    source_id, source_name, source_phone, source_address
  } = req.swagger.params.body.value;

  db.query('UPDATE master_catalog.source SET "sourceName" = $1, "contactNumber" = $2, "address" = $3 WHERE "sourceId" = $4', [source_name, source_phone, source_address, source_id])
    .then(() => {
      res.send(response.success('Source Data has been updated successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/*
    * Function: Delete a Source
    * Param 1: sourceID is Required Field
    * Delete (status=0) a Source by Source ID
  */
function sourceDelete(req, res) {
  const source_id = req.swagger.params.sourceid.value;

  db.query('UPDATE master_catalog.source SET "status" = $1 WHERE "sourceId" = $2', [0, source_id])
    .then(() => {
      res.send(response.success('Deleted successfully', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/*
    * Function: Get the Source Data by ID
  */
function sourceById(req, res) {
  const sourceid = req.swagger.params.sourceid.value;

  db.query(`SELECT "sourceId", "sourceName", "status", "contactNumber", "address" FROM master_catalog.source where "sourceId" = ${sourceid} AND "status" = 1 `)
    .then((source_data) => {
      res.send(response.success('data refresh', source_data[0]));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
