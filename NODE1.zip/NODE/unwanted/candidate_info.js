const util = require('util');
const Cryptr = require('cryptr');
const jwt_decode = require('jwt-decode');
const response = require('../../config/response');
const utilities = require('./../helpers/commonFunctions');
const sqlQueries = require('./../../config/queries/sqlQueries');
const conf = require('./../../config');

const cryptr = new Cryptr(conf.get('url').encrytptionKey);

module.exports = {
  candidateInfo,
  allCandidates,
  singleCandidate,
  updateCandidateInfo,
  deleteCandidateInfo,
  filedownload,
  candidateCheckExsist,
  candidateUpdateStatus,
  getCandidateListBasedOnType,
  interviewaction
};

/**
 * Add Candidate Information
 * @returns status message
 */
function candidateInfo(req, res) {
  const datas = JSON.parse(req.body.data);

  const fileName = (datas.filename).replace(/'/g, '');
  const filesave = utilities.base64_decode(datas.fileValue, fileName);

  datas.workExpYears = datas.workExpYears ? datas.workExpYears : 0;
  datas.workExpMonths = datas.workExpMonths ? datas.workExpMonths : 0;
  datas.currentSalLakhs = datas.currentSalLakhs ? datas.currentSalLakhs : 0;
  datas.currentSalThousands = datas.currentSalThousands ? datas.currentSalThousands : 0;
  datas.expectSalLakhs = datas.expectSalLakhs ? datas.expectSalLakhs : 0;
  datas.expectSalThousands = datas.expectSalThousands ? datas.expectSalThousands : 0;
  datas.officialNoticePeriod = datas.officialNoticePeriod ? datas.officialNoticePeriod : 0;
  datas.negotiableNoticePeriod = datas.negotiableNoticePeriod ? datas.negotiableNoticePeriod : 0;
  datas.resourceType = datas.resourceType ? datas.resourceType : 0;
  datas.customerID = datas.customerID ? datas.customerID : 0;
  datas.candidateType = datas.candidateType ? datas.candidateType : 2; // Temparory

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const user_id = decoded.userId;

  if (filesave) {
    db.query(`INSERT INTO candidate_catalog.candidate_details("candidateFirstName", "candidateEmailId", "candidateMobileNo", "candidateType", "workExpYears", "workExpMonths", "currentSalLakhs", "currentSalThousands", "expectSalLakhs", "expectSalThousands", "officialNoticePeriod", "negotiableNoticePeriod", "resume", "candidateSource", "sourceId", "candidateLastName", "alternateMobileNo", "candidateDOB", "resourceType",  "customerId", "status", "createdBy", "createdOn") VALUES ('${datas.candidateFirstName}','${datas.candidateEmailId}','${datas.candidateMobileNo}','${datas.candidateType}','${datas.workExpYears}','${datas.workExpMonths}','${datas.currentSalLakhs}','${datas.currentSalThousands}','${datas.expectSalLakhs}','${datas.expectSalThousands}','${datas.officialNoticePeriod}','${datas.negotiableNoticePeriod}','${filesave}','${datas.sourceName}','${datas.sourceReferral}','${datas.candidateLastName}','${datas.alternateMobileNo}','${datas.candidateDOB}','${datas.resourceType}','${datas.customerID}', 1, ${user_id}, now())  RETURNING "candidateId", "candidateFirstName", "createdOn" `)
      .then((data) => {
        // forming query for candidate_stack_details
        let techqry = 'INSERT INTO candidate_catalog.candidate_stack_details("candidateId", "stackId", status) VALUES ';

        if (datas.customerID != 0) {
          db.none(`UPDATE customer_catalog.client_details SET "clientStatus" = 2 WHERE "clientId" = ${datas.customerID}`)
            .then(() => {});
        }

        const id = data[0].candidateId;

        // max index of array
        const max = datas.categoryId.length - 1;

        // checking it is array or not
        // if(max > 0) {
        // looping the technology id
        datas.categoryId.forEach((element, index) => {
          // forming the query
          techqry += `(${data[0].candidateId},${element},1)`;
          if (index != max) {
            techqry += ',';
          }
        });

        db.query(techqry)
          .then(() => {
            // responce

            res.send(response.success('Candidate Information Saved Successfully', {
              id
            }));
            const auditSubCategoryId = 4;
            utilities.postLogData(auditSubCategoryId, data[0].createdOn, data[0].candidateFirstName, token);
          })
          .catch((err) => {
            if (util.isError(err)) res.error('NotFoundError', err); // return 404
            else res.error('InternalServerError', err); // else 500
          });
      }).catch((err) => {
        if (util.isError(err)) res.error('NotFoundError', err); // return 404
        else res.error('InternalServerError', err); // else 500
      });
  }
}
/**
 * get Candidate Information
 *  @param pageCount  pagecount
 *  @param page  to dispaly page
 *  @param sortColumn  for sorting column
 *  @param sortOrder  for sorting order
 *  @param filterValue  for filter value
 */
function allCandidates(req, res) {
  const {
    pagecount,
    page,
    sort_column,
    sort_order
  } = req.query;
  const filterValue = req.query.filter_value;
  const filterInterviwer = req.query.filter_interviwer;
  const filterCustomer = req.query.filter_customer;

  let pagelimit = 0;

  if (pagecount != '') {
    pagelimit = (page - 1) * pagecount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';
  let subQuery = '';
  let selectVal = '';

  if (pagecount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pagecount} OFFSET ${pagelimit}`;
  }

  if ((sort_column != '' && sort_column != undefined) && (sort_order != '' && sort_order != undefined)) {
    orderby += ` ORDER BY "${sort_column}" ${sort_order}`;
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (a."candidateFirstName" ILIKE '%${filterValue}%' OR a."candidateLastName" ILIKE '%${filterValue}%' OR clnt."clientName" ILIKE '%${filterValue}%' OR CAST(b."scheduleDate" AS TEXT) ILIKE '%${filterValue}%' OR CAST(a."candidateMobileNo" AS TEXT) ILIKE '%${filterValue}%' ) `;
  }

  if (filterInterviwer) {
    filter += ` AND ( a."candidateAcceptBy" IN(${filterInterviwer}) OR a."interviewerActionedBy" IN(${filterInterviwer}) ) `;
  }

  if (filterCustomer) {
    filter += ` AND ( a."customerId" = ${filterCustomer}) `;
  }

  subQuery = ' LEFT JOIN interview_catalog.schedule_interview AS b ON b."scheduleId" = (SELECT "scheduleId" FROM interview_catalog.schedule_interview WHERE "candidateId" = a."candidateId" ORDER BY "scheduleId" DESC, "scheduleDate" DESC LIMIT 1 OFFSET 0) ';
  subQuery += ' LEFT JOIN master_catalog."user" AS usr ON usr."userId" = a."candidateAcceptBy" ';
  subQuery += ' LEFT JOIN customer_catalog.client_details AS clnt ON clnt."clientId" = a."customerId" ';
  subQuery += ' LEFT JOIN customer_catalog.client_details AS clt ON clt."clientId" = a."oldCustomerId" ';
  subQuery += ' LEFT JOIN master_catalog."user" AS usr1 ON usr1."userId" = a."interviewerActionedBy" ';
  subQuery += ' LEFT JOIN master_catalog."user" AS usr2 ON usr2."userId" = a."HrActionedBy" ';
  subQuery += ' LEFT JOIN master_catalog."user" AS usr3 ON usr3."userId" = a."customerActionedBy" ';

  selectVal = ', (CASE WHEN a."candidateAcceptStatus" = 11 THEN \'Cancelled\' WHEN a."candidateAcceptStatus" = 1 THEN \'Accepted\' WHEN a."candidateAcceptStatus" = 2 THEN \'Selected\'  WHEN a."candidateAcceptStatus" = 3 THEN \'Rejected\' WHEN a."candidateAcceptStatus" = 4 THEN \'Didn’t Pick\' WHEN a."candidateAcceptStatus" = 5 THEN \'Rescheduled\' WHEN a."candidateAcceptStatus" = 6 THEN \'Selected\' WHEN a."candidateAcceptStatus" = 7 THEN \'Rejected\' WHEN a."candidateAcceptStatus" = 8 THEN \'Customer Selected\' WHEN a."candidateAcceptStatus" = 9 THEN \'Customer Rejected \' WHEN a."candidateAcceptStatus" = 10 THEN \'Reassigned\' ELSE \'Created\' END) AS candidateStatus ';
  // selectVal += ', (CASE WHEN a."interviewerActionedStatus" = 2 THEN \'Selected\'  WHEN a."interviewerActionedStatus" = 3 THEN \'Rejected\' ELSE \'-\' END) AS interviewerstatus ';
  // selectVal += ', (CASE WHEN a."HrActionedStatus" = 6 THEN \'Selected\' WHEN a."HrActionedStatus" = 7 THEN \'Rejected\' ELSE \'-\' END) AS hrstatus ';
  // selectVal += ', (CASE WHEN a."customerActionedStatus" = 8 THEN \'Customer Selected\' WHEN a."customerActionedStatus" = 9 THEN \'Customer Rejected\' ELSE \'-\' END) AS customerstatus ';
  selectVal += `, (CASE WHEN a."interviewerActionedStatus" = 1 THEN 'Accepted' WHEN a."interviewerActionedStatus" = 2 THEN 'Selected' WHEN a."interviewerActionedStatus" = 3 THEN 'Rejected' WHEN a."interviewerActionedStatus" = 4 THEN 'Didn’t Pick' WHEN a."interviewerActionedStatus" = 5 THEN 'Rescheduled' ELSE '-' END) AS interviewerstatus `;
  selectVal += `, (CASE WHEN a."HrActionedStatus" = 6 THEN 'Selected' WHEN a."HrActionedStatus" = 7 THEN 'Rejected' WHEN a."HrActionedStatus" = 11 THEN 'Cancelled' WHEN a."HrActionedStatus" = 4 THEN 'Didn’t Pick' WHEN a."HrActionedStatus" = 10 THEN 'Reassigned' ELSE '-' END) AS hrstatus `;
  selectVal += `, (CASE WHEN a."customerActionedStatus" = 8 THEN 'Customer Selected' WHEN a."customerActionedStatus" = 9 THEN 'Customer Rejected' ELSE '-' END) AS customerstatus `;

  const finalQuery = `SELECT DISTINCT a."candidateId", concat(a."candidateFirstName",' ',a."candidateLastName") AS candidatefullname, a."candidateFirstName", a."candidateReferedBy", a."candidateEmailId", a."candidateMobileNo", a."categoryId", a."candidateType", a."customerId", a."resourceType", b."scheduleId", to_char(b."scheduleDate", 'DD-MM-YYYY') AS scheduledate, DATE_PART('day', a."candidateTentativeJOD" - now() ) AS tentativedays, to_char(a."candidateTentativeJOD", 'DD-MM-YYYY') AS tentativejod, TO_CHAR(b."scheduleFromTime",'hh:mi AM') AS schedulefromtime, TO_CHAR(b."scheduleToTime",'hh:mi AM') AS scheduletotime ${selectVal}, a."candidateAcceptStatus", a."candidateAcceptBy", a."interviewerActionedBy", a."HrActionedBy", a."interviewerActionedStatus", a."HrActionedStatus", usr."name", usr1."name" AS intervieweredby, clnt."clientName", clt."clientName" AS oldclientname, usr2."name" AS hractionby, a."customerActionedStatus", a."customerActionedBy", usr3."name" AS customeractionby FROM candidate_catalog.candidate_details AS a ${subQuery} where a."status" = 1 ${filter} ${orderby} ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.one(`SELECT COUNT(a."candidateId") FROM candidate_catalog.candidate_details AS a ${subQuery} where a."status" = 1 ${filter}`)
  ]))
    .then((sourceData) => {
      const opt = {};
      opt.datas = sourceData[0];
      opt.total_count = sourceData[1].count;
      res.send(response.success('', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
/**
 * get single candidate Information
 *  @param id  to get candidate information
 */
function singleCandidate(req, res) {
  const id = req.swagger.params.userId.value;
  db.task((t) => {
    // fetch candidate information from candidate details
    //  old query -> `select "candidateFirstName","candidateEmailId","candidateMobileNo","candidateType","workExpYears","workExpMonths","currentSalLakhs","currentSalThousands","expectSalLakhs","expectSalThousands","officialNoticePeriod","negotiableNoticePeriod","resume","candidateSource","sourceId","candidateLastName","alternateMobileNo","candidateDOB" from candidate_catalog.candidate_details where "status" = 1 and "candidateId" = ${id}`
    return t.one(`select DISTINCT a."candidateId", "candidateFirstName", "candidateEmailId", "candidateMobileNo", "candidateType", "workExpYears", "workExpMonths", "currentSalLakhs",      "currentSalThousands", "expectSalLakhs", "expectSalThousands", "officialNoticePeriod", "negotiableNoticePeriod", "resume", "candidateSource", "sourceId", "candidateLastName", "alternateMobileNo", "candidateDOB", to_char(b."scheduleDate", 'DD-MM-YYYY') AS scheduledate, concat(a."candidateFirstName",' ',a."candidateLastName") AS candidatefullname,
      (CASE WHEN a."candidateAcceptStatus" = 11 THEN 'Cancelled' WHEN a."candidateAcceptStatus" = 1 THEN 'Accepted' WHEN a."candidateAcceptStatus" = 2 THEN 'Selected' WHEN a."candidateAcceptStatus" = 3 THEN 'Rejected' WHEN a."candidateAcceptStatus" = 4 THEN 'Didn’t Pick' WHEN a."candidateAcceptStatus" = 5 THEN 'Rescheduled' ELSE 'Created' END) AS candidateStatus, usr."name", clnt."clientName", w."workflowName", TO_CHAR(b."scheduleFromTime",'hh:mi AM') AS schedulefromtime, TO_CHAR(b."scheduleToTime",'hh:mi AM') AS scheduletotime, a."customerId", a."resourceType", cas."canAcceptStatusCommants"
      from candidate_catalog.candidate_details AS a
      LEFT JOIN interview_catalog.schedule_interview AS b ON a."candidateId" = b."candidateId"
      LEFT JOIN master_catalog."user" AS usr ON usr."userId" = a."candidateAcceptBy"
      LEFT JOIN customer_catalog.client_details AS clnt ON clnt."clientId" = a."customerId"
    LEFT JOIN master_catalog.workflow AS w ON b."workflowId" = w."workflowId"
    LEFT JOIN candidate_catalog.candidate_action_status AS cas ON a."candidateId" = cas."canAcceptCandidateId"
      where a."status" = 1 and a."candidateId" = ${id} ORDER BY scheduledate desc limit 1`)
      .then((candidateInfo) => {
        // if exist then fetch candidate stack infromation from candidate stack details
          if (candidateInfo.length > 0) {
          return t.any(`select "candidateId", "stackId" from candidate_catalog.candidate_stack_details where "status" = 1 and "candidateId" = ${id}`).then((stackInfo) => {
            if (stackInfo) {
              candidateInfo.categoryId = [];
              stackInfo.forEach((key, value) => {
                candidateInfo.categoryId.push(key.stackId);
              });
            }
            return { candidateInfo };
          });
        }
        return { candidateInfo };
      });
  })
    .then((data) => {
      res.send(response.success('Fetched Candidate Information Successfully', data.candidateInfo));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
/**
 * update candidate Information
 *  @param candidateInfo  total form information to update
 */
function updateCandidateInfo(req, res) {
  const file = req.swagger.params.file.value;
  const candidateInfo = JSON.parse(req.swagger.params.data.value);

  let filesave = '';
  let fileName = '';

  if (candidateInfo.filename) {
    fileName = (candidateInfo.filename).replace(/'/g, '');
    filesave = utilities.base64_decode(candidateInfo.fileValue, fileName);
  }

  // set default values
  candidateInfo.workExpYears = candidateInfo.workExpYears ? candidateInfo.workExpYears : 0;
  candidateInfo.workExpMonths = candidateInfo.workExpMonths ? candidateInfo.workExpMonths : 0;
  candidateInfo.currentSalLakhs = candidateInfo.currentSalLakhs ? candidateInfo.currentSalLakhs : 0;
  candidateInfo.currentSalThousands = candidateInfo.currentSalThousands ? candidateInfo.currentSalThousands : 0;
  candidateInfo.expectSalLakhs = candidateInfo.expectSalLakhs ? candidateInfo.expectSalLakhs : 0;
  candidateInfo.expectSalThousands = candidateInfo.expectSalThousands ? candidateInfo.expectSalThousands : 0;
  candidateInfo.officialNoticePeriod = candidateInfo.officialNoticePeriod ? candidateInfo.officialNoticePeriod : 0;
  candidateInfo.negotiableNoticePeriod = candidateInfo.negotiableNoticePeriod ? candidateInfo.negotiableNoticePeriod : 0;
  candidateInfo.candidateType = candidateInfo.candidateType ? candidateInfo.candidateType : 1;
  // File upload functionalites
  let resume;
  if (filesave) {
    resume = `"resume"='${filesave}'`;
  }
  // query concatnation
  let qry = `UPDATE candidate_catalog.candidate_details SET "candidateFirstName"='${candidateInfo.candidateFirstName}', "candidateEmailId"='${candidateInfo.candidateEmailId}', "candidateMobileNo"='${candidateInfo.candidateMobileNo}', "candidateType"='${candidateInfo.candidateType}', "workExpMonths"='${candidateInfo.workExpMonths}', "workExpYears"='${candidateInfo.workExpYears}', "currentSalLakhs"='${candidateInfo.currentSalLakhs}', "currentSalThousands"='${candidateInfo.currentSalThousands}', "expectSalLakhs"='${candidateInfo.expectSalLakhs}', "expectSalThousands"='${candidateInfo.expectSalThousands}', "officialNoticePeriod"='${candidateInfo.officialNoticePeriod}', "alternateMobileNo"='${candidateInfo.alternateMobileNo}', "candidateLastName"='${candidateInfo.candidateLastName}', "candidateDOB"='${candidateInfo.candidateDOB}', "negotiableNoticePeriod"='${candidateInfo.negotiableNoticePeriod}', "status" = 1, "candidateReferedBy" = '${candidateInfo.candidateReferedBy}', `;
  if (file) {
    qry += `${resume},`;
  }
  qry += `"candidateSource"='${candidateInfo.sourceName}',"sourceId"='${candidateInfo.sourceReferral}' WHERE "candidateId" = '${candidateInfo.candidateId}' `;

  // Update Query
  db.query(qry)
    .then(() => {
      /**
             * delete previes record and insert the updated record for candidateId
             */
      const del = `DELETE FROM candidate_catalog.candidate_stack_details WHERE  "candidateId" = ${candidateInfo.candidateId} and status = 1`;
      db.query(del)
        .then(() => {
          /**
                     * insering the record after deleting
                     */
          let techqry = 'INSERT INTO candidate_catalog.candidate_stack_details("candidateId", "stackId", status) VALUES ';
          const max = candidateInfo.categoryId.length - 1; // max index of array
          // forming insert query
          if (candidateInfo.categoryId) {
            candidateInfo.categoryId.forEach((element, index) => {
              techqry += `('${candidateInfo.candidateId}','${element}',1)`;
              if (index != max) {
                techqry += ',';
              }
            });
          }
          // inserting
          db.query(techqry)
            .then(() => {
              const id = {
                id: candidateInfo.candidateId
              };
              // responce
              res.send(response.success('Candidate Information Updated Successfully', id));
            });
          // insering ends hear
        });
    })
    .catch((err) => { // update candidate details catch
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
/**
 * delete Cabdidate Info data
 * @requires id of the row to delte the Candidate Info
 * @returns status message
 */
function deleteCandidateInfo(req, res) {
  const {
    id
  } = req.query;
  const token = req.headers.authorization;
  // delete query
  db.query(`UPDATE candidate_catalog.candidate_details SET "status"= 0 WHERE "candidateId" = ${id} RETURNING "candidateFirstName", "modifiedOn"`)
    .then((data) => {
      res.send(response.success('Candidate Information Deleted Successfully', []));
      const auditSubCategoryId = 5;
      utilities.postLogData(auditSubCategoryId, data[0].modifiedOn, data[0].candidateFirstName, token);
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
/**
 * gives file path for download
 * @requires filename the name of the file to get path
 * @returns status message
 */
function filedownload(req, res) {
  const path = `${__dirname}/../../uploads/${req.query.filename}`;

  const base64_file = utilities.base64_encode(path);
  const base64_fileContent = Buffer.from(base64_file, 'base64');

  res.send(response.success('File Downloaded Successfully.', base64_file));
  
}

/**
 * Candidate Checks if Exsists or not
 * @requires e-mail or Phone Number
 * @returns Candidate already have or not.
 */
function candidateCheckExsist(req, res) {
  let {
    email_id,
    phone_no
  } = req.query;

  email_id = email_id || '';
  phone_no = phone_no || '';

  let where = '';

  if (phone_no != '') {
    where = `OR "alternateMobileNo" = '${phone_no}' `;
  }

  db.query(`SELECT "candidateId", "candidateFirstName", "candidateLastName", "candidateEmailId", "candidateMobileNo", "alternateMobileNo", "candidateType", "workExpYears", "workExpMonths", "candidateDOB", "resume", "candidateSource", "sourceId", "status", concat("candidateFirstName",' ',"candidateLastName") AS candidatefullname FROM candidate_catalog.candidate_details WHERE ("candidateEmailId" = '${email_id}' OR "candidateMobileNo" = '${phone_no}' ${where} )`)
    .then((existData) => {
      const existObj = {};

      existObj.data = existData[0];
      const status = existData[0] ? 1 : 0;
      existObj.status = status;

      res.send(response.success('', existObj));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Candidate Information Pickuped from user
 * @requires User token and status
 */
function candidateUpdateStatus(req, res) {
  const candidate_id = req.swagger.params.candidateId.value;
  const statusId = req.swagger.params.status_id.value;
  const scheduleId = req.swagger.params.schedule_id.value;
  const commends = req.swagger.params.commends.value;
  const tentative_jod = req.swagger.params.tentativejod.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const user_id = decoded.userId;
  const user_name = decoded.name;
  const user_role = decoded.role;
  const byemail = false;

  changecandiatestatus(byemail, candidate_id, statusId, scheduleId, user_id, user_name, commends, tentative_jod, user_role, token)
    .then((data) => {
      res.send(response.success(`Candidate has been ${data} Successfully`, []));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * acepting the candidate from mail
 * @requires Userid and action
 */
function interviewaction(req, res) {
  const bodyval = req.swagger.params.body.value;
  const body = (cryptr.decrypt(bodyval.url)).split('/');
  const candidate_id = body[2];
  const statusId = body[3];
  const scheduleId = body[0];
  const user_id = body[1];

  const acceptStatus = statusId;
  let user_name = '';
  const byemail = true;
  // status 1 => accepted "column a.candidateTentativeJOD does not exist"
  // status 2 => already accepted by you
  // status 3 => already accepted by others
  // status 4 => declained by you
  // status 5 => already declained by you
  if (acceptStatus == 1) {
    db.query(`SELECT cd."candidateId", cd."candidateAcceptStatus", cd."candidateAcceptBy", ud."name" FROM candidate_catalog.candidate_details AS cd
        LEFT JOIN master_catalog."user" as ud ON cd."candidateAcceptBy" = ud."userId"
        where "candidateId" = ${candidate_id}`)
      .then((data) => {
        // when it was not already accepted
        if (data[0].candidateAcceptStatus === 0) {
          db.query(`SELECT "name" from master_catalog."user" WHERE "userId" = ${user_id} `)
            .then((userdetail) => {
              user_name = userdetail[0].name;
              changecandiatestatus(byemail, candidate_id, statusId, scheduleId, user_id, user_name)
                .then((data) => {
                  const respdata = {
                    status: 1,
                    message: 'You have accepted the candidate Successfully'
                  };
                  res.send(response.success('success', respdata));
                })
                .catch((err) => {
                  if (util.isError(err)) res.error('NotFoundError', err); // return 404
                  else res.error('InternalServerError', err); // else 500
                });
            });
        } else {
          // when it was already accepted
          const respdata = {
            status: (data[0].candidateAcceptBy == user_id) ? 2 : 3,
            message: (data[0].candidateAcceptBy == user_id) ? 'This Candidate has been already Accepted by You' : `This candidate has been already Accepted by ${data[0].name}`,
            candidateAcceptStatus: data[0].candidateAcceptStatus,
            name: data[0].name
          };
          res.send(response.success('success', respdata));
        }
      })
      .catch((err) => {
        if (util.isError(err)) res.error('NotFoundError', err); // return 404
        else res.error('InternalServerError', err); // else 500
      });
  } else if (acceptStatus == 2) {
    // if declained
    db.query(`SELECT "interviewer" FROM interview_catalog.schedule_interview WHERE "candidateId" = ${candidate_id}`)
      .then((data) => {
        if (data[0].interviewer) {
          const interviewer = data[0].interviewer;
          const str_array = interviewer.split(',');
          const index = str_array.indexOf(user_id);
          if (index > -1) {
            str_array.splice(index, 1);
          }
          const interviewer1 = (str_array.join()) ? str_array.join() : '';
          db.query(`UPDATE interview_catalog.schedule_interview set "interviewer"= '${interviewer1}' WHERE "candidateId" = ${candidate_id}`)
            .then((data) => {
              const respdata = {
                status: 4,
                message: 'You have sucessfully Declined'
              };
              res.send(response.success('success', respdata));
            });
        } else {
          const respdata = {
            status: 5,
            message: 'You have already Declined'
          };
          res.send(response.success('success', respdata));
        }
      });
  }
}

/**
 * changes the status of the candidate
 * @param byemail boolean
 * @param candidate_id
 * @param statusId
 * @param scheduleId
 * @param user_id details from JWT
 * @param user_name details from JWT
 * @param [commends] reason for accept/ reject
 * @param [tentative_jod]
 * @param [token] JWT token
 * @returns promise with status name
 */
function changecandiatestatus(byemail, candidate_id, statusId, scheduleId, user_id, user_name, commends = undefined, tentative_jod = undefined, user_role = undefined, token = undefined) {
  return new Promise((resolve, reject) => {
    let candidateDate = '';

    if (tentative_jod) {
      tentative_jod = formatDate(tentative_jod);
      candidateDate = `, "candidateTentativeJOD" = '${tentative_jod}'`;
    }

    if (user_role == 1) {
      candidateDate += `, "HrActionedBy" = '${user_id}', "HrActionedStatus" = '${statusId}'`;
    } else if (user_role == 2 || user_role == 4) {
      candidateDate += `, "interviewerActionedBy" = '${user_id}', "interviewerActionedStatus" = '${statusId}'`;
    } else if (user_role == 3) {
      candidateDate += `, "customerActionedStatus" = '${user_id}', "customerActionedBy" = '${statusId}'`;
    }

    const logData = {};

    db.query(`UPDATE candidate_catalog.candidate_details SET "candidateAcceptStatus" = ${statusId}, "candidateAcceptBy" = ${user_id} ${candidateDate} WHERE "candidateId" = ${candidate_id} RETURNING "modifiedOn"`)
      .then((data) => {
        // inserting the reason for sellect/ reject
        if (statusId == '2' || statusId == '3' || statusId == '6' || statusId == '7' || statusId == '8' || statusId == '9') {
          utilities.updatecomments(candidate_id, statusId, user_id, commends);
        }

        if (statusId == 1) {
          db.query(`UPDATE interview_catalog.schedule_interview SET "interviewer" = '${user_id}' WHERE "scheduleId" = ${scheduleId}`)
            .then(() => {});

          db.query(`INSERT INTO interview_catalog.assigned_interviewer("scheduleId","interviewerId","status") VALUES ('${scheduleId}', '${user_id}', 1) `)
            .then(() => {});
        }

        db.query(`INSERT INTO interview_catalog.schedule_interview_history("scheduleHistoryUserId", "scheduleHistoryCandidateStatus", "scheduleHistoryScheduleId", "scheduleHistoryCandidateId") VALUES ('${user_id}', '${statusId}', '${scheduleId}', '${candidate_id}') `)
          .then(() => {});


        const status = (statusId == 1) ? 'Accepted' : (statusId == 2) ? 'Selected' : (statusId == 3) ? 'Rejected' : (statusId == 4) ? 'Didn’t Pick' : (statusId == 5) ? 'Rescheduled' : (statusId == 6) ? 'Selected' : (statusId == 7) ? 'Rejected' : (statusId == 8) ? 'Customer Selected' : (statusId == 9) ? 'Customer Rejected' : (statusId == 10) ? 'Reassigned' : (statusId == 11) ? 'Cancelled' : 'Created';
        const color = (statusId == 1) ? '#1787a0' : (statusId == 2) ? '#008000' : (statusId == 3) ? '#d03506' : (statusId == 4) ? '#08059cd6' : (statusId == 5) ? '#008000' : (statusId == 6) ? '#004526' : (statusId == 7) ? '#BF1920' : (statusId == 8) ? '#004526' : (statusId == 9) ? '#BF1920' : (statusId == 10) ? '#20c997' : (statusId == 11) ? '#BF1920' : '#1787a0';
        
        const mailData = {};
        mailData.temName = 'interview/InterviewerStatusSend';
        mailData.subject = 'Screener App - Candidate Status';

        mailData.interviewerName = user_name;

        mailData.colorCode = color;
        mailData.candidateStatus = status;

        logData.status = status;
        logData.status_id = statusId;
        logData.modifiedOn = data[0].modifiedOn;

        return db.query(`SELECT a."candidateFirstName", a."candidateLastName", concat(a."candidateFirstName",' ',a."candidateLastName") AS candidatefullname, a."candidateEmailId", a."candidateMobileNo", a."alternateMobileNo", a."candidateType", a."workExpYears", a."workExpMonths", a."candidateDOB", a."status", b."emailId", b."name" FROM candidate_catalog.candidate_details AS a LEFT JOIN master_catalog.user AS b ON a."createdBy" = b."userId" WHERE a."status"= 1 and a."candidateId" = ${candidate_id}`)
          .then((candidateDetails) => {
            if (candidateDetails) {
              mailData.emailId = candidateDetails[0].emailId;

              mailData.candidateName = candidateDetails[0].candidatefullname;
              mailData.candidateEmail = candidateDetails[0].candidateEmailId;
              mailData.candidatePhone = candidateDetails[0].candidateMobileNo;
              mailData.hrName = candidateDetails[0].name;

              utilities.sendEmail(mailData);
              logData.candidateName = candidateDetails[0].candidatefullname;
            }
            return logData;
          });
      }).then((logData) => {
        const auditSubCategoryId = (logData.status == 'Selected') ? 6 : (logData.status == 'Rejected') ? 7 : (logData.status == 'Didn’t Pick') ? 8 : (logData.status == 'Rescheduled') ? 9 : 10;
        if (byemail === false) {
          utilities.postLogData(auditSubCategoryId, logData.modifiedOn, logData.candidateName, token);
        } else {
          utilities.postLogData(auditSubCategoryId, logData.modifiedOn, logData.candidateName, '', user_id);
        }

        // resolve the promise
        resolve(logData.status);
      })
      .catch((err) => {
        console.error(err);
      });
  });
}

/**
 * @name: formatDate
 *
 * Change the Date format.
*/
function formatDate(date) {
  const d = new Date(date);

  let month = `${d.getMonth() + 1}`;
  let day = `${d.getDate()}`;
  const year = d.getFullYear();
  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;

  return [year, month, day].join('-');
}

/**
 * @name: getCandidateListBasedOnType
 *
 * @description
 * Get candidates based on the type given by the user
 *
 * @returns {Object} response
 */
function getCandidateListBasedOnType(req, res) {
  const type = req.swagger.params.type.value;
  const interviewerId = req.swagger.params.interviewerId.value;

  switch (type) {
    case 1:
    {
      const scheduledInterviewersQuery = `${sqlQueries.candidateInfo.candidatesBasedOnType} where a."status" = 1 AND a."candidateAcceptStatus" = 1 AND a."candidateAcceptBy" = ${interviewerId}`;

      db.query(scheduledInterviewersQuery)
        .then((scheduledInterviewers) => {
          res.send(response.success('Successfully Retrived accepted candidated', scheduledInterviewers));
        }).catch((err) => {
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
        });
      break;
    }
    case 2:
    {
      const yetToAcceptCandidatesQuery = `${sqlQueries.candidateInfo.candidatesBasedOnType} where a."candidateAcceptStatus" = 0 and ('${interviewerId}' = ANY (string_to_array(b."interviewer",',')))`;

      db.query(yetToAcceptCandidatesQuery)
        .then((yetToAcceptCandidates) => {
          res.send(response.success('Successfully Retrived candidates to accept', yetToAcceptCandidates));
        }).catch((err) => {
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
        });
      break;
    }
    case 3:
    {
      const pendingCandidatesQuery = `${sqlQueries.candidateInfo.candidatesBasedOnType} where a."candidateAcceptStatus" = 0 and b."interviewer" = ''`;

      db.query(pendingCandidatesQuery)
        .then((pendingCandidates) => {
          res.send(response.success('Successfully Retrived pending candidates', pendingCandidates));
        }).catch((err) => {
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
        });
      break;
    }
    default:
    {
      // throw error if request type is not valid
      const err = utilities.validationErrorHandling();
      err.body.errorResponse.msg = `Request validation failed: Parameter (type) is not an allowable value (1, 2, 3):${type}`;
      if (util.isError(err)) res.error('BadRequestError', err); // return 404
      else res.error('InternalServerError', err); // else 500
      break;
    }
  }
}
