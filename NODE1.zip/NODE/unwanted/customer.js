/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-sequences */
/* eslint-disable no-unused-expressions */
/* eslint-disable arrow-body-style */
const util = require('util');
const _ = require('lodash');
const jwtDecode = require('jwt-decode');
const response = require('../../config/response');
const utilities = require('./../helpers/commonFunctions');

module.exports = {
  postCustomerDetails,
  updateCustomerDetails,
  deleteCustomerDetails,
  postCustomerRequirement,
  updateCustomerRequirement,
  deleteCustomerRequirement,
  postResourceDetails,
  updateResourceDetails,
  deleteResourceDetails,
  getAllClientDetails,
  getClientDetails,
  getResourceDetails,
  updateClientResourceDetails,
  getCustomerDetailswithCandidates,
  customerStatusUpdate,
  getViewClientDetails,
  assignedResource,
  candidateChangeCustomer
};

/**
 * Name: customerInfo
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer
 *
 * The listed @params below will used for insert query
 * @params  - body formData
 */
function postCustomerDetails(req, res) {
  const {
    clientName,
    contactNo,
    address,
    country,
    state,
    emailAddress,
    isActive
  } = req.swagger.params.body.value;

  db.none(`INSERT INTO customer_catalog.client_details("clientName", "contactNo", "address", "country", "state", "emailAddress","createdByUserId", "isActive") VALUES ('${clientName}', '${contactNo}', '${address}', '${country}', '${state}', '${emailAddress}', '${createByUserId}', '${isActive}')`)
    .then(() => {
      res.send(response.success('Client Details Added Successfully', {}));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: updateCustomerDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function updateCustomerDetails(req, res) {
  const {
    clientId,
    clientName,
    contactNo,
    address,
    country,
    state,
    emailAddress,
    createdByUserId,
    isActive
  } = req.swagger.params.body.value;

  db.none('UPDATE customer_catalog.client_details SET "clientName" = $1, "contactNo" = $2, "address" = $3, "country" = $4, "state" = $5, "emailAddress" = $6, "createdByUserId" = $7, "isActive" = $8 WHERE "clientId" = $9', [clientName, contactNo, address, country, state, emailAddress, createdByUserId, isActive, clientId])
    .then(() => {
      res.send(response.success('Client Updated Successfully', {}));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: deleteCustomerDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function deleteCustomerDetails(req, res) {
  const clientId = req.swagger.params.clientId.value;

  db.none('UPDATE customer_catalog.client_details SET "isActive" = $1 WHERE "clientId" = $2', [false, clientId])
    .then(() => {
      res.send(response.success('Deleted successfully', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: postCustomerRequirement
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/requirement
 *
 * The listed @params below will used for insert query
 * @params  - body
 */
function postCustomerRequirement(req, res) {
  const {
    clientId,
    numberOfResources,
    isActive
  } = req.swagger.params.body.value;
  const token = req.headers.authorization;

  db.query(`INSERT INTO customer_catalog.requirement_details("clientId", "numberOfResources", "isActive", "createdOn") VALUES ('${clientId}', '${numberOfResources}', '${isActive}', now()) RETURNING "clientId", "createdOn"`)
    .then((data) => {
      res.send(response.success('Client Requirements Added Successfully', {}));
      const auditSubCategoryId = 1;
      db.query(`SELECT "clientId", "clientName" FROM customer_catalog.client_details where "clientId" = ${data[0].clientId}`)
        .then((details) => {
          utilities.postLogData(auditSubCategoryId, data[0].createdOn, details[0].clientName, token);
        });
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: updateCustomerRequirement
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/requirement
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function updateCustomerRequirement(req, res) {
  const {
    reqId,
    clientId,
    numberOfResources,
    isActive
  } = req.swagger.params.body.value;
  const token = req.headers.authorization;
  db.query('UPDATE customer_catalog.requirement_details SET "clientId" = $1, "numberOfResources" = $2, "isActive" = $3 WHERE "reqId" = $4 RETURNING "clientId", "modifiedOn"', [clientId, numberOfResources, isActive, reqId])
    .then((data) => {
      res.send(response.success('Client Requirements Updated Successfully', {}));
      const auditSubCategoryId = 2;
      db.query(`SELECT "clientId", "clientName" FROM customer_catalog.client_details where "clientId" = ${data[0].clientId}`)
        .then((details) => {
          utilities.postLogData(auditSubCategoryId, data[0].modifiedOn, details[0].clientName, token);
        });
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: deleteCustomerRequirement
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/requirement
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function deleteCustomerRequirement(req, res) {
  const reqId = req.swagger.params.reqId.value;
  const token = req.headers.authorization;
  db.query('UPDATE customer_catalog.requirement_details SET "isActive" = $1 WHERE "reqId" = $2 RETURNING "clientId", "modifiedOn"', [false, reqId])
    .then((data) => {
      res.send(response.success('Deleted successfully', []));
      const auditSubCategoryId = 3;
      db.query(`SELECT "clientId", "clientName" FROM customer_catalog.client_details where "clientId" = ${data[0].clientId}`)
        .then((details) => {
          utilities.postLogData(auditSubCategoryId, data[0].modifiedOn, details[0].clientName, token);
        });
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: postResourceDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/resource_details
 *
 * The listed @params below will used for insert query
 * @params  - file formData
 *          - data formData
 */
function postResourceDetails(req, res) {
  const file = req.files;
  const data = JSON.parse(req.swagger.params.data.value);
  const userdetails = utilities.getjwtdetails(req);
  const userid = userdetails.userId;

  db.task(t => t.query(`INSERT INTO customer_catalog.client_details("clientName", "contactNo", "address", "country", "state", "emailAddress","createdByUserId", "isActive", "assignedTo", "clientStatus") VALUES ('${data.clientName}', '${data.contactNo}', '${data.address}', '${data.country}', '${data.state}', '${data.emailAddress}', ${userid}, '1', '${data.assignedTo}', '0') RETURNING "clientId" `)
    .then((customerInfo) => {
      if (customerInfo[0]) {
        return t.query(`INSERT INTO customer_catalog.requirement_details("clientId", "numberOfResources", "isActive") VALUES ('${customerInfo[0].clientId}', '${data.numberOfResources}', 'true') RETURNING "reqId"`).then((requirementInfo) => {
          if (requirementInfo[0]) {
            let resourcedetails = '';

            for (const i in data.resourceInformation) {
              let filesave = '';
              let fileName = '';

              if (data.resourceInformation[i].jdFilePath.filename) {
                fileName = (data.resourceInformation[i].jdFilePath.filename).replace(/'/g, '');
                filesave = utilities.base64_decode(data.resourceInformation[i].jdFilePath.value, fileName);
              }

              resourcedetails += `(${requirementInfo[0].reqId}, ${data.resourceInformation[i].resourceType}, '${filesave}', '${data.resourceInformation[i].experience}', ${data.resourceInformation[i].leadTime}, '${data.resourceInformation[i].technologyLists}', 'true','${data.resourceInformation[i].numberOfPositions}'),`;
            }
            resourcedetails = resourcedetails.slice(0, -1);
            return t.query(`INSERT INTO customer_catalog.resource_details("reqId", "resourceType", "jdFilePath", "experience", "leadTime", "technologyLists", "isActive","numberOfPositions")VALUES ${resourcedetails} RETURNING "resId"`)
              .then((resourceInfo) => {
                const dataDetails = {
                  cusData: data,
                  resId: resourceInfo[0].resId
                };
                return dataDetails;
              });
          }
        });
      }
    })).then((detailData) => {
    res.json(response.success('Customer Added Successfully', {
      id: detailData.resId
    }));

    const datas = detailData.cusData;

    if (datas.assignedTo) {
      const mailData = {};
      mailData.temName = 'interview/RequestInterview';
      mailData.subject = 'Screener App - Interview Request';
      mailData.clientName = datas.clientName;
      mailData.clientEmail = datas.emailAddress;
      mailData.clientNumber = datas.contactNo;
      mailData.clientCountry = datas.country;
      mailData.resourceClient = datas.numberOfResources;

      db.query(`SELECT "userId", "name", "emailId", "role" FROM master_catalog.user WHERE "status" = 1 and "userId" = ${datas.assignedTo} `)
        .then((dataEmail) => {
          mailData.emailId = dataEmail[0].emailId;
          mailData.candidateName = dataEmail[0].name;

          utilities.sendEmail(mailData);
        });
    }
  }).catch((err) => {
    if (util.isError(err)) res.error('NotFoundError', err); // return 404
    else res.error('InternalServerError', err); // else 500
  });
}


/**
 * Name: updateResourceDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/resource_details
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function updateResourceDetails(req, res) {
  const {
    resId,
    reqId,
    resourceType,
    experience,
    leadTime,
    stackId,
    isActive
  } = req.swagger.params.body.value;

  db.none('UPDATE customer_catalog.resource_details SET "reqId" = $1, "resourceType" = $2, "experience" = $3, "leadTime" = $4, "stackId" =$5, "isActive"= $6 WHERE "resId" = $7', [reqId, resourceType, experience, leadTime, stackId, isActive, resId])
    .then(() => {
      res.send(response.success('Client Resource Details Updated Successfully', {}));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: deleteResourceDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/resource_details
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function deleteResourceDetails(req, res) {
  const resId = req.swagger.params.resId.value;

  db.none('UPDATE customer_catalog.resource_details SET "isActive" = $1 WHERE "resId" = $2', [false, resId])
    .then(() => {
      res.send(response.success('Deleted Successfully', {}));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getClientDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /candidate
 *
 * The listed @params below will used for select query
 *  @param pageCount  pagecount
 *  @param page  to dispaly page
 *  @param sortColumn  for sorting column
 *  @param sortOrder  for sorting order
 *  @param filterValue  for filter value
 */
function getAllClientDetails(req, res) {
  const pageCount = req.swagger.params.pagecount.value;
  const page = req.swagger.params.page.value;
  const sortColumn = req.swagger.params.sort_column.value;
  const sortOrder = req.swagger.params.sort_order.value;
  const filterValue = req.swagger.params.filter_value.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwtDecode(token);

  const user_role = decoded.role;

  let client_status = '';

  if (user_role == 4) {
    client_status += ' AND a."clientStatus" = 0 ';
  } else if (user_role == 3) {
    client_status += ' AND a."clientStatus" >= 0 ';
  } else {
    client_status += ' AND a."clientStatus" >= 1 ';
  }

  /* Calculate the Limit and Order by via Page */
  const filterValues = utilities.dataRange(pageCount, page, sortColumn, sortOrder, 'clientId');

  const orderby = filterValues.orderby;
  const limit = filterValues.limit;

  let filter = '';

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (a."clientName" ILIKE '%${filterValue}%' OR a."emailAddress" ILIKE '%${filterValue}%' OR a."contactNo" ILIKE '%${filterValue}%') `;
  }

  caseSel = ' (CASE WHEN a."clientStatus" = 2 THEN \'In Progress\' WHEN a."clientStatus" = 3 THEN \'Closed\' WHEN a."clientStatus" = 4 THEN \'Hold\' WHEN a."clientStatus" = 5 THEN \'Completed\' ELSE \'Initiated\' END) AS  clientstatus';
  caseSel += ', (SELECT COUNT("candidateId") FROM candidate_catalog.candidate_details where "status" = 1 and "customerId" = a."clientId") AS candidatecount ';
  caseSel += ', (SELECT count("candidateId") FROM candidate_catalog.candidate_details WHERE "status" = 1 and ("candidateAcceptStatus" = 2 OR "candidateAcceptStatus" = 6) and "customerId" = a."clientId" ) AS candidateselected ';

  const finalQuery = `SELECT DISTINCT a."clientId", a."clientName", a."contactNo", a."emailAddress", b."numberOfResources", a."clientStatus", TO_CHAR(a."createdAt" :: DATE, 'dd-mm-yyyy') AS createdAt, a."assignedTo", a."createdByUserId" , ${caseSel} FROM customer_catalog.client_details AS a JOIN customer_catalog.requirement_details AS b ON a."clientId" = b."clientId" where a."isActive" = true and b."isActive" = true ${client_status} ${filter} ${orderby} ${limit} `;
  db.tx(t => t.batch([
    t.any(finalQuery),
    t.any(`SELECT COUNT(a."clientId") FROM customer_catalog.client_details AS a where a."isActive" = true ${filter}`)
  ]))
    .then((clientDetails) => {
      const opt = {};
      opt.datas = clientDetails[0];
      opt.total_count = clientDetails[1][0].count;


      res.send(response.success('Client Details', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: getClientDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/{clientId}
 *
 * The listed @params below will used for select query
 *  @param clientId  clientId
 */
function getClientDetails(req, res) {
  const clientId = req.swagger.params.clientId.value;

  caseSel = ' (CASE WHEN a."clientStatus" = 2 THEN \'In Progress\' WHEN a."clientStatus" = 3 THEN \'Closed\' WHEN a."clientStatus" = 4 THEN \'Hold\' WHEN a."clientStatus" = 5 THEN \'Completed\' ELSE \'Initiated\' END) AS  clientstatus';
  caseSel += `, (SELECT COUNT("candidateId") FROM candidate_catalog.candidate_details where "status" = 1 and "customerId" = ${clientId}) AS candidateCount `;

  db.query(`SELECT "clientId", "clientName", "contactNo", "address", "country", "state", "emailAddress","createdByUserId", "isActive", "assignedTo", a."clientStatus", TO_CHAR(a."createdAt" :: DATE, 'dd-mm-yyyy') AS createdAt, ${caseSel} FROM customer_catalog.client_details where "clientId" = ${clientId}`)
    .then((details) => {
      // details.interviewRoundId = JSON.parse(details.interviewRoundId);
      res.send(response.success('Client Details', details));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: getResourceDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /resource/{clientId}:
 *
 * The listed @params below will used for select query
 *  @param reqId  reqId
 */
function getResourceDetails(req, res) {
  const clientId = req.swagger.params.clientId.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwtDecode(token);

  const user_id = decoded.userId;
  const user_role = decoded.role;

// execute a chain of queries against the task context, and return the result:
  db.task((t) => {
    return t.query(`SELECT "clientName", "emailAddress", "contactNo", "address", "country", "state", "isActive", "clientStatus", "assignedTo" FROM customer_catalog.client_details where "clientId" = $1`, [clientId])
      .then((clientDetails) => {
        if (clientDetails.length) {
          return t.any('SELECT "reqId", "numberOfResources" FROM customer_catalog.requirement_details where "clientId" = $1', [clientId])
            .then((requirementDetails) => {
              const subQuery = ', (SELECT count("resAllocId") FROM customer_catalog.resource_allocation WHERE "resAllocResId" = a."resId" ) AS allocount';

              const join = ' JOIN master_catalog.resource_designation as b ON b."designationId" =  CAST(a."resourceType" AS INTEGER) ';

              return t.any(`SELECT a."resId", a."resourceType", a."jdFilePath", a."experience", a."leadTime", a."stackId", a."technologyLists", a."numberOfPositions", b."designationName"${subQuery} FROM customer_catalog.resource_details as a ${join} where a."reqId" = '${requirementDetails[0].reqId}' and b."designationStatus" = 1 `)
                .then((resourceInformation) => {
                  clientDetails[0].numberOfResources = requirementDetails[0].numberOfResources;
                  clientDetails[0].reqId = requirementDetails[0].reqId;
                  const clientData = clientDetails[0];
                  let allocationDetails = [];

                  if (resourceInformation.length > 0) {
                    let resourceIds = '';
                    resourceInformation.forEach((key, value) => {
                      resourceIds += `${key.resId},`;
                      if (key.allocount >= key.numberOfPositions) {
                        db.query(`UPDATE customer_catalog.client_details SET "clientStatus" = 2 WHERE "clientId" = $1`, [clientId]).then((updateCli) => {
                        });
                      }
                    });
                    resourceIds = resourceIds.slice(0, -1);

                    return t.any(`SELECT "resAllocId", "resAllocClientId", "resAllocResId", "resAllocCandidateType", "resAllocUserBy", "resAllocDate", "resAllocPosition", "resAllocReqId" FROM customer_catalog.resource_allocation where "resAllocResId" IN(${resourceIds}) ORDER BY "resAllocResId", "resAllocPosition" `)
                      .then((allocationDetail) => {
                        const detailAllocation = allocationDetail.reduce((r, a) => {
                          r[a.resAllocResId] = r[a.resAllocResId] || [];
                          r[a.resAllocResId][a.resAllocPosition] = a;
                          return r;
                        }, Object.create(null));

                        /* allocationDetails = _.map(detailAllocation, (value, resourceType) => ({ resourceType)); */

                        allocationDetails = detailAllocation;

                        return {
                          clientData,
                          resourceInformation,
                          allocationDetails
                        };
                      });
                  }
                  return {
                    clientData,
                    resourceInformation,
                    allocationDetails
                  };
                });
            });
        }
      });
  })
    .then((data) => {
      const output = data.clientData;
      output.resourceInformation = data.resourceInformation;
      output.allocationDetails = data.allocationDetails;
      res.send(response.success('Resource Details', output));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Name: updateClientResourceDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/resource_details
 *
 * The listed @params below will used for update query
 * @params  - body
 */
function updateClientResourceDetails(req, res) {
  const file = req.files;
  const data = JSON.parse(req.swagger.params.data.value);
  db.task((t) => {
    return t.any('UPDATE customer_catalog.client_details SET "clientName" = $1, "contactNo" = $2, "address" = $3, "country" = $4, "state" = $5, "emailAddress" = $6, "assignedTo" = $7 WHERE "clientId" = $8 RETURNING "clientId"', [data.clientName, data.contactNo, data.address, data.country, data.state, data.emailAddress, data.assignedTo, data.clientId])
      .then((customerInfo) => {
        if (customerInfo[0]) {
          return t.any('UPDATE customer_catalog.requirement_details SET "clientId" = $1, "numberOfResources" = $2 WHERE "reqId" = $3 RETURNING "reqId"', [customerInfo[0].clientId, data.numberOfResources, data.reqId])
            .then((requirementInfo) => {
              if (requirementInfo[0]) {
                return t.none(`DELETE FROM customer_catalog.resource_details WHERE "reqId" = ${requirementInfo[0].reqId}`)
                  .then(() => {
                    const fileArray = [];

                    let resourcedetails = '';
                    for (let i = 0; i < data.resourceInformation.length; i++) {
                      let filesave = '';
                      let fileName = '';

                      if (data.resourceInformation[i].jdFilePath.filename) {
                        fileName = (data.resourceInformation[i].jdFilePath.filename).replace(/'/g, '');
                        filesave = utilities.base64_decode(data.resourceInformation[i].jdFilePath.value, fileName);
                      } else {
                        filesave = data.resourceInformation[i].jdFilePath;
                      }

                      resourcedetails += `(${requirementInfo[0].reqId}, '${data.resourceInformation[i].resourceType}', '${filesave}', '${data.resourceInformation[i].experience}', ${data.resourceInformation[i].leadTime}, '${data.resourceInformation[i].technologyLists}', 'true','${data.resourceInformation[i].numberOfPositions}'),`;
                    }
                    resourcedetails = resourcedetails.slice(0, -1);
                    return t.none(`INSERT INTO customer_catalog.resource_details("reqId", "resourceType", "jdFilePath", "experience", "leadTime", "technologyLists", "isActive","numberOfPositions") VALUES ${resourcedetails}`)
                      .then(() => {
                        res.json(response.success('Client and Resource details Updated Successfully'));
                      });
                  });
              }
            });
        }
      });
  })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getCustomerDetailswithCandidates
 * Info: Based on the swagger.yaml file endpoint for
 *        /customerdetails/{clientid}
 *
 * The listed @params below will used for select query
 * @params  - clientid
 */
function getCustomerDetailswithCandidates(req, res) {
  const clientid = req.swagger.params.clientid.value;

// execute a chain of queries against the task context, and return the result:
  db.task((t) => {
    return t.query('SELECT "clientId", "clientName", "emailAddress", "contactNo", "address", "country", "state", "isActive", "assignedTo" AS assignToHr, "clientStatus" FROM customer_catalog.client_details where "clientId" = $1', [clientid])
      .then((clientDetails) => {
        if (clientDetails.length) {
          return t.any('SELECT "reqId", "numberOfResources" FROM customer_catalog.requirement_details where "clientId" = $1', [clientid])
            .then((requirementDetails) => {
              return t.any('SELECT "resId", "resourceType", "jdFilePath", experience, "leadTime", "stackId", "technologyLists", "numberOfPositions" FROM customer_catalog.resource_details where "reqId" = $1', [requirementDetails[0].reqId])
                .then((resourceInformation) => {
                  clientDetails[0].numberOfResources = requirementDetails[0].numberOfResources;

                  const clientData = clientDetails[0];

                  let unAssignedResourceTypes = [];
                  let result = [];

                  if (resourceInformation.length > 0) {
                    let resourceId = '';
                    const resourceIdArray = [];
                    const resourceInfoArray = [];
                    resourceInformation.forEach((key, value) => {
                      resourceId += `${key.resourceType},`;
                      resourceIdArray.push(key.resourceType);
                      resourceInfoArray[key.resourceType] = key;
                    });
                    resourceId = resourceId.slice(0, -1);

                    let subQuery = '';
                    subQuery += ' LEFT JOIN master_catalog.user AS usr ON a."candidateAcceptBy" = usr."userId" ';
                    subQuery += ' LEFT JOIN interview_catalog.schedule_interview AS b ON a."candidateId" = b."candidateId" ';
                    subQuery += ' LEFT JOIN master_catalog."user" AS usr1 ON usr1."userId" = a."interviewerActionedBy" ';
                    subQuery += ' LEFT JOIN master_catalog."user" AS usr2 ON usr2."userId" = a."HrActionedBy" ';
                    subQuery += ' LEFT JOIN master_catalog."user" AS usr3 ON usr3."userId" = a."customerActionedBy" ';

                    let selectVal = ' (CASE WHEN a."candidateAcceptStatus" = 1 THEN \'Accepted\' WHEN a."candidateAcceptStatus" = 2 THEN \'Selected\' WHEN a."candidateAcceptStatus" = 3 THEN \'Rejected\' WHEN a."candidateAcceptStatus" = 4 THEN \'Didn’t Pick\' WHEN a."candidateAcceptStatus" = 5 THEN \'Rescheduled\' WHEN a."candidateAcceptStatus" = 6 THEN \'Selected\' WHEN a."candidateAcceptStatus" = 7 THEN \'Rejected\' WHEN a."candidateAcceptStatus" = 8 THEN \'Customer Selected\' WHEN a."candidateAcceptStatus" = 9 THEN \'Customer Rejected \' WHEN a."candidateAcceptStatus" = 10 THEN \'Reassigned\' ELSE \'Created\' END) AS candidatestatus ';
                    // selectVal += `, () AS totalpos`;

                    selectVal += ', (CASE WHEN a."interviewerActionedStatus" = 2 THEN \'Selected\'  WHEN a."interviewerActionedStatus" = 3 THEN \'Rejected\' ELSE \'-\' END) AS interviewerstatus ';
                    selectVal += ', (CASE WHEN a."HrActionedStatus" = 6 THEN \'Selected\' WHEN a."HrActionedStatus" = 7 THEN \'Rejected\' ELSE \'-\' END) AS hrstatus ';
                    selectVal += ', (CASE WHEN a."customerActionedStatus" = 8 THEN \'Customer Selected\' WHEN a."customerActionedStatus" = 9 THEN \'Customer Rejected\' ELSE \'-\' END) AS customerstatus ';

                    return t.any(`SELECT a."candidateId", a."candidateFirstName", a."candidateEmailId", concat(a."candidateFirstName",' ',a."candidateLastName") AS candidatefullname, a."candidateMobileNo", a."candidateType", a."workExpYears", a."workExpMonths", a."expectSalLakhs", a."expectSalThousands", a."officialNoticePeriod", a."negotiableNoticePeriod", a."candidateLastName", a."candidateDOB", a."resourceType", a."customerId", a."candidateAcceptStatus", ${selectVal}, a."candidateAcceptBy", usr.name, to_char(b."scheduleDate", 'DD-MM-YYYY') AS scheduledate, DATE_PART('day', now() - a."candidateTentativeJOD" ) AS tentativedays, to_char(a."candidateTentativeJOD", 'DD-MM-YYYY') AS tentativejod, TO_CHAR(b."scheduleFromTime", 'hh:mi AM') AS schedulefromtime, TO_CHAR(b."scheduleToTime", 'hh:mi AM') AS scheduletotime, usr1."name" AS intervieweredby, usr2."name" AS hractionby, a."interviewerActionedBy", a."HrActionedBy", a."interviewerActionedStatus", a."HrActionedStatus", a."customerActionedStatus", a."customerActionedBy", usr3."name" AS customeractionby FROM candidate_catalog.candidate_details as a ${subQuery} WHERE a."status" = 1 and a."customerId" = ${clientid} and a."resourceType" IN(${resourceId}) `)
                      .then((candidateInfo) => {
                        let i = 1;

                        let candidateDetails = candidateInfo.reduce(function(r, a) {
                          r[a.resourceType] = r[a.resourceType] || [];
                          r[a.resourceType].push(a);
                          return r;
                        }, Object.create(null));

                        // if(candidateDetails.length > 0) {
                            result = _.map(candidateDetails, (value, resourceType) => ({
                              resourceType,
                              value
                            }));
                        // }

                        let j = 0;
                        if (result.length > 0) {
                          resourceIdArray.forEach((value, key) => {
                            if (result[j]) {
                              const resource_type = result[j].resourceType;

                              if (!resourceIdArray.includes(resource_type)) {
                                unAssignedResourceTypes.push(resourceInfoArray[value]);
                                resourceInfoArray.splice(resource_type, 1);
                              }
                            } else {
                              unAssignedResourceTypes.push(resourceInfoArray[value]);
                            }
                            j++;
                          });
                        } else {
                          unAssignedResourceTypes = resourceInformation;
                        }

                        return {
                          clientData,
                          resourceInformation,
                          result,
                          unAssignedResourceTypes
                        };
                      });
                  }

                  return {
                    clientData,
                    resourceInformation,
                    result,
                    unAssignedResourceTypes
                  };
                });
            });
        }
      });
  })
    .then((data) => {
      const output = data.clientData;
      output.resourceInformation = data.resourceInformation;
      output.candidateDetails = data.result;
      output.unAssignedResourceTypes = data.unAssignedResourceTypes;
      res.send(response.success('Resource Details', output));
    })
    .catch((err) => {
      console.log(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: customerStatusUpdate
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/customerstatus
 *
 * The listed @params below will used for select query
 * @params  - clientid
 */
function customerStatusUpdate(req, res) {
  const client_id = req.swagger.params.clientid.value;
  const update_status = req.swagger.params.updatestatus.value;

  db.none(`UPDATE customer_catalog.client_details SET "clientStatus" = ${update_status} WHERE "clientId" = ${client_id}`)
    .then(() => {
      res.send(response.success('Client status changed successfully.', []));
    })
    .catch((err) => {
      console.log(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: getViewClientDetails
 * Info: Based on the swagger.yaml file endpoint for
 *        /viewcustomer
 *
 * The listed @params below will used for select query
 *
 */
function getViewClientDetails(req, res) {
  const pageCount = req.swagger.params.pagecount.value;
  const page = req.swagger.params.page.value;
  const sortColumn = req.swagger.params.sort_column.value;
  const sortOrder = req.swagger.params.sort_order.value;
  const filterValue = req.swagger.params.filter_value.value;

  /* Calculate the Limit and Order by via Page */
  const filterValues = utilities.dataRange(pageCount, page, sortColumn, sortOrder, 'clientId');

  const orderby = filterValues.orderby;
  const limit = filterValues.limit;

  let filter = '';

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (a."clientName" ILIKE '%${filterValue}%' OR a."emailAddress" ILIKE '%${filterValue}%' OR a."contactNo" ILIKE '%${filterValue}%') `;
  }

  caseSel = ' (CASE WHEN a."clientStatus" = 2 THEN \'In Progress\' WHEN a."clientStatus" = 3 THEN \'Closed\' WHEN a."clientStatus" = 4 THEN \'Hold\' WHEN a."clientStatus" = 5 THEN \'Completed\' ELSE \'Initiated\' END) AS clientstatus';

  const finalQuery = `SELECT a."clientId", a."clientName", a."contactNo", a."emailAddress", a."clientStatus", TO_CHAR(a."createdAt" :: DATE, 'dd-mm-yyyy') AS createdAt, b."numberOfResources", b."reqId", a."assignedTo", a."createdByUserId", ${caseSel} FROM customer_catalog.client_details AS a JOIN customer_catalog.requirement_details AS b ON a."clientId" = b."clientId" where a."isActive" = true and b."isActive" = true and a."clientStatus" < 3 ${filter} ${orderby} ${limit} `;

  db.task((t) => {
    return t.query(finalQuery)
      .then((clientDetails) => {
        /* return t.any(`SELECT DISTINCT COUNT(a."clientId") FROM customer_catalog.client_details AS a JOIN customer_catalog.requirement_details AS b ON a."clientId" = b."clientId" ${join} where a."isActive" = true and b."isActive" = true and a."clientStatus" < 2 ${filter}`)
                                                                                    .then(clientCount => { */
        const clientDatas = {};

        if (clientDetails.length) {
          clientDatas.datas = clientDetails;
          clientDatas.total_count = clientDetails.length;

          requestIds = '';
          const requestsId = [];
          if (clientDetails.length > 0) {
            clientDetails.forEach((value, key) => {
              const idx = requestsId.indexOf(value.reqId);
              if (idx == -1) {
                requestsId.push(value.reqId);
                requestIds += `${value.reqId},`;
              }
            });
            requestIds = requestIds.slice(0, -1);
          }

          return t.any(`SELECT count("resId") as resourcecount, SUM("numberOfPositions") AS resourcesum, "reqId", "resourceType" FROM customer_catalog.resource_details where "isActive" = true and "reqId" IN(${requestIds}) group by "reqId", "resourceType" `)
            .then((resourceDetails) => {
              clientDatas.resource = resourceDetails;
              return clientDatas;
            });
        }
        return clientDatas;
      });
  })
    .then((finalDetails) => {
      res.send(response.success('Client Details', finalDetails));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: assignedResource
 * Info: Based on the swagger.yaml file endpoint for
 *        /resource/assigned
 *
 * The listed @params below will used for select query
 *
 */
function assignedResource(req, res) {
  const {
    resId,
    reqId,
    candidateType,
    clientId,
    position,
    empUserId
  } = req.swagger.params.body.value;

  const employeeUserId = (empUserId) || 0;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwtDecode(token);

  const user_id = decoded.userId;

  db.one(`INSERT INTO customer_catalog.resource_allocation("resAllocResId", "resAllocReqId", "resAllocClientId", "resAllocCandidateType", "resAllocUserBy", "resAllocPosition", "resAllocEmployeeId") VALUES (${resId}, ${reqId}, ${clientId}, ${candidateType}, ${user_id}, ${position}, ${employeeUserId}) RETURNING "resAllocId" `)
    .then((allocData) => {
        db.query(`SELECT "numberOfPositions", (SELECT count("resAllocId") FROM customer_catalog.resource_allocation WHERE "resAllocResId" = a."resId" ) AS allocount FROM customer_catalog.resource_details AS a WHERE a."reqId" = ${reqId} `)
        .then((resourceAlloc) => {
            if(resourceAlloc[0].allocount >= resourceAlloc[0].numberOfPositions){
                db.query(`UPDATE customer_catalog.client_details SET "clientStatus" = 2 WHERE "clientId" = '${clientId}' `)
                .then(() => {

                });
            }
        });
      res.send(response.success('Resource Allocated Successfully.', allocData));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Name: candidateChangeCustomer
 * Info: Based on the swagger.yaml file endpoint for
 *        /customer/changecustomer
 *
 * The listed @params below will used for select query
 *
 */
function candidateChangeCustomer(req, res) {
  const {
    candidateId,
    scheduleId,
    oldcustomerId,
    customerId
  } = req.swagger.params.body.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwtDecode(token);

  const user_id = decoded.userId;

  db.one(`INSERT INTO customer_catalog.client_changes_history("clienHisCandidateId", "clienHisScheduleId", "clienHisOldCustomerId", "clienHisCustomerId", "clienHisUserId") VALUES (${candidateId}, ${scheduleId}, ${oldcustomerId}, ${customerId}, ${user_id}) RETURNING "clienHisId" `)
    .then((dataCus) => {
      console.log(dataCus);
      const historyId = dataCus.clienHisId;

      db.query(`UPDATE candidate_catalog.candidate_details SET "customerId" = ${customerId}, "oldCustomerId" = ${oldcustomerId}, "clienHisId" = ${historyId} WHERE "candidateId" = '${candidateId}' `)
        .then(() => {
          res.send(response.success('Candidate changed customer successfully.', []));
        });
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
