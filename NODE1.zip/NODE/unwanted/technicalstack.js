const util = require('util');
const response = require('../../config/response');
const sqlQueries = require('../../config/queries/sqlQueries');


/*
 'use strict' is not required but helpful for turning syntactical errors into true errors in the program flow
 https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode
*/

/*
 Modules make it possible to import JavaScript files into your application.  Modules are imported
 using 'require' statements that give you a reference to the module.

  It is a good idea to list the modules that your application depends on in the package.json in the project root
 */

/*
 Once you 'require' a module you can reference the things that it exports.  These are defined in module.exports.

 For a controller in a127 (which this is) you should export the functions referenced in your Swagger document by name.

 Either:
  - The HTTP Verb of the corresponding operation (get, put, post, delete, etc)
  - Or the operationId associated with the operation in your Swagger document

  In the starter/skeleton project the 'get' operation on the '/hello' path has an operationId named 'hello'.  Here,
  we specify that in the exports of this module that 'hello' maps to the function named 'hello'
 */
module.exports = {
  getTechnicalStack,
  addTechnicalStack,
  editTechnicalStack,
  deteteTechnicalStack
};

/**
 * get technical stack details
 * @returns json
 */
function getTechnicalStack(req, res) {
  // optional parameters pagecount , page, sort_column, sort_order to get the requered result

  const {
    pagecount,
    page,
    sort_column,
    sort_order
  } = req.query;
  const filterValue = req.query.filter_value;

  let pagelimit = 0;

  if (pagecount != '') {
    pagelimit = (page - 1) * pagecount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';
  if (pagecount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pagecount} OFFSET ${pagelimit}`;
  }

  if ((sort_column != '' && sort_column != undefined) && (sort_order != '' && sort_order != undefined)) {
    orderby = ` ORDER BY "${sort_column}" ${sort_order}`;
  } else {
    orderby = ' ORDER BY "stackName" ASC ';
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND ("stackName" LIKE '%${filterValue}%')`;
  }

  const finalQuery = `${sqlQueries.technicalstack.select} ${filter} ${orderby} ${limit}`;
  const searchQuery = `${sqlQueries.technicalstack.count} ${filter}`;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.one(searchQuery)
  ]))
    .then((sourceData) => {
      const opt = {};
      opt.datas = sourceData[0];
      opt.total_count = sourceData[1].count;
      res.send(response.success('', opt));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * add technical stack
 * @requires stackname to add the new technical stack
 * @returns status message
 */
function addTechnicalStack(req, res) {
  const { stackname } = req.body;
  // checking the value is already exist in DB or not
  db.query(sqlQueries.technicalstack.validate.add, [stackname])
    .then((check) => {
      if (check.length == 0) {
        db.query(sqlQueries.technicalstack.insert, [stackname])
          .then(() => {
            res.send(response.success('Technical stack added'));
          })
          .catch((err) => {
            if (util.isError(err)) res.error('NotFoundError', err); // return 404
            else res.error('InternalServerError', err); // else 500
          });
      } else {
        res.send(response.error('stack already exists'));
      }
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * edits technical stack data
 * @requires stackname data to be edited in technical stack
 * @requires stackid id of the row which should be edited
 * @returns status message
 */
function editTechnicalStack(req, res) {
  const { stackname, stackid } = req.body;

  // checking the value is already exist in DB or not
  db.query(sqlQueries.technicalstack.validate.edit, [stackname, stackid])
    .then((check) => {
      if (check.length == 0) {
        // if thare is no duplicate
        db.query(sqlQueries.technicalstack.update, [stackname, stackid])
          .then(() => {
            res.send(response.success('Technical stack updated', []));
          })
          .catch((err) => {
            if (util.isError(err)) res.error('NotFoundError', err); // return 404
            else res.error('InternalServerError', err); // else 500
          });
      } else {
        res.send(response.error('stack already exists'));
      }
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * delete technical stack data
 * @requires id id of the row to delte the technical stack
 * @returns status message
 */
function deteteTechnicalStack(req, res) {
  const { id } = req.query;

  db.query(sqlQueries.technicalstack.delete, [id])
    .then(() => {
      res.send(response.success('Deleted successfully', []));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
