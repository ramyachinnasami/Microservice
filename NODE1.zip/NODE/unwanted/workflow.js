const util = require('util');
const response = require('../../config/response');
const sqlQueries = require('../../config/queries/sqlQueries');
const conf = require('../helpers/commonFunctions');

module.exports = {
  getAllWorkflow,
  addWorkflowData,
  workflowUpdate,
  singleworkflowdetails,
  deteteWorkflow
};

/*
Function: Select all WorkFlow
req: a handle to the request object
res: a handle to the response object
*/
function getAllWorkflow(req, res) {
  const pageCount = req.swagger.params.pagecount.value;
  const page = req.swagger.params.page.value;
  const sortColumn = req.swagger.params.sort_column.value;
  const sortOrder = req.swagger.params.sort_order.value;
  const filterValue = req.swagger.params.filter_value.value;

  /* Calculate the Limit and Order by via Page */
  const filterValues = conf.dataRange(pageCount, page, sortColumn, sortOrder, 'workflowName');

  const orderby = filterValues.orderby;
  const limit = filterValues.limit;

  let filter = '';

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND ("workflowName" LIKE '%${filterValue}%') `;
  }
  const finalQuery = `SELECT DISTINCT "workflowId", "workflowName","interviewRoundId","status" FROM master_catalog.workflow where "status" = 1 ${filter} ${orderby} ${limit} `;
  db.tx(t => t.batch([
    t.any(finalQuery),
    t.any(`SELECT COUNT("workflowId") FROM master_catalog.workflow where "status" = 1 ${filter}`)
  ]))
    .then((dataWorkflow) => {
      const opt = {};
      opt.datas = dataWorkflow[0];
      opt.total_count = dataWorkflow[1][0].count;


      res.send(response.success('data refresh', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/*
    Function: Insert a Source
    req: sourcename is Required Field
    res: other Fields is optional (sourcephno, sourceaddress)
  */
function addWorkflowData(req, res) {
  let { workflowName, interviewRoundId } = req.swagger.params.body.value;
  interviewRoundId = interviewRoundId.toString();
  db.none('INSERT INTO master_catalog.workflow("workflowName", "status", "interviewRoundId") VALUES($1, $2, $3)', [workflowName, 1, interviewRoundId])
    .then(() => {
      res.send(response.success('Workflow data has been inserted successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/*
 * Function: Update a Source
 */
function workflowUpdate(req, res) {
  let { workflowId, workflowName, interviewRoundId } = req.swagger.params.body.value;
  interviewRoundId = interviewRoundId.toString();
  db.query('UPDATE master_catalog.workflow SET "workflowName" = $1, "interviewRoundId" = $2 WHERE "workflowId" = $3', [workflowName, interviewRoundId, workflowId])
    .then(() => {
      res.send(response.success('Workflow data has been updated successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

function singleworkflowdetails(req, res) {
  const id = req.swagger.params.id.value;
  db.one('SELECT "workflowId", "workflowName", status, "interviewRoundId" FROM master_catalog.workflow where "workflowId" = $1', [id])
    .then((details) => {
      const details_array = details.interviewRoundId.split(',');
      details.interviewRoundId = details_array.map(String);
      res.send(response.success('workflow details', details));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

function deteteWorkflow(req, res) {
  const { id } = req.swagger.params.id.value;

  db.query('DELETE FROM master_catalog.workflow WHERE "workflowId" = $1', [id])
    .then(() => {
      res.send(response.success('Deleted successfully', []));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
