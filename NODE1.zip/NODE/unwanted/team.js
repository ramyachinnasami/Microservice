
const util = require('util');
const jwt_decode = require('jwt-decode');
const response = require('../../config/response');

module.exports = {
  getAllTeam,
  getTeamById,
  deleteTeam,
  getUsersByType,
  addTeam
};


/**
 * getSelectedCandidates Information
 *  @param pageCount  pagecount
 *  @param page  to dispaly page
 *  @param sortColumn  for sorting column
 *  @param sortOrder  for sorting order
 *  @param filterValue  for filter value
 */
function getAllTeam(req, res) {
  const {
    pagecount,
    page,
    sort_column,
    sort_order
  } = req.query;
  const filterValue = req.query.filter_value;

  let pagelimit = 0;

  if (pagecount != '') {
    pagelimit = (page - 1) * pagecount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';
  if (pagecount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pagecount} OFFSET ${pagelimit}`;
  }

  if ((sort_column != '' && sort_column != undefined) && (sort_order != '' && sort_order != undefined)) {
    orderby = `"${sort_column}" ${sort_order}`;
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND (a."name" ILIKE '%${filterValue}%') `;
  }


  const finalQuery = `select row_number() over() as sno,  a."userId" as dmid, a."name" as "deliverymanager", a."role", a."userTeam",  string_agg(b."name", ', ') as teamuser  FROM "master_catalog"."user" a left join   "master_catalog"."user" as b on  b."userId" = any (string_to_array(a."userTeam",',')::int[]) where a."status"=1 and a."role"=4 and a."userTeam"!=''  ${filter} Group by a."userId" ORDER BY ${orderby} ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.one('select count(a."userId") FROM "master_catalog"."user" a where a."status"=1 and a."role"=4 and a."userTeam"!=\'\' ')
  ]))
    .then((sourceData) => {
      const opt = {};
      opt.datas = sourceData[0];
      opt.total_count = sourceData[1].count;
      res.send(response.success('Successfully Retrived Team List', opt));
    })
    .catch((err) => {
      console.log(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


function getTeamById(req, res) {

}

/**
 *
 * @param {userId} req get userid for team
 * @param {*} res success or error message throw
 */
function deleteTeam(req, res) {
  const teamid = req.swagger.params.user_id.value;
  db.query('UPDATE master_catalog.user SET "userTeam"=null WHERE "userId"=$1', teamid)
    .then(() => {
      res.send(response.success('Team has been deleted successfully', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 *
 * @param { type } req get user list based on type
 * @param { response } res
 */
function getUsersByType(req, res) {
  const type = req.swagger.params.type.value;
  let where = '';
  if (type == 'dm') {
    where += 'AND role = 4';
  } else if (type == 'user') {
    where += 'AND role = 2';
  }

  db.query(`SELECT "userId", "name" FROM master_catalog.user WHERE "status"=1 ${where}`)
    .then((result) => {
      res.send(response.success(' ', result));
    }).catch((err) => {
      console.log(err);
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 *
 * @param {deliverymanager, userid} req
 * @param {insertedId} res
 */
function addTeam(req, res) {
  let {
    deliverymanager, userTeam, dmid, status
  } = req.swagger.params.body.value;

  status = (status != '') ? status : 'created';

  userTeam = (userTeam).toString();
  db.none('UPDATE master_catalog.user SET "userTeam"= $1 WHERE "userId" = $2', [userTeam, dmid])
    .then(() => {
      res.send(response.success(`Team has been ${status} successfully.`, []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
