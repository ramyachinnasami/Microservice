const util = require('util');
const jwt_decode = require('jwt-decode');
const sql = require('mssql');
const response = require('../../config/response');
const conf = require('../helpers/commonFunctions');


const config = {
  user: 'HRMS_Dev',
  password: 'hrm5$dev123',
  server: 'DSRCWIN2016\\SQLEXPRESS2017',
  database: 'HRMS_Dev'
};

module.exports = {
  getAllUsers,
  getAllUserRoles,
  addUser,
  updateUser,
  deleteUser,
  getUserDataByEmail,
  getUserDataByRole,
  getDesignations,
  getUnassignedUsers
};

/**
 * Select all interview Scheduler List
 */
function getAllUsers(req, res) {
  // variables defined in the Swagger document can be referenced using req.swagger.params.{parameter_name}
  const pageCount = req.query.pagecount;
  const page = req.query.page;
  const sortColumn = req.query.sort_column;
  const sortOrder = req.query.sort_order;
  const filterValue = req.query.filter_value;


  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  const user_id = decoded.userId;

  let pagelimit = 0;
  if (pageCount != '' && pageCount != undefined) {
    pagelimit = (page - 1) * pageCount;
  }

  if (page == 1) {
    pagelimit = 0;
  }

  let limit = '';
  let orderby = '';
  let filter = '';
  let subQuery = '';
  const where = '';
  const selectVal = '';

  if (pageCount > 0 && pagelimit >= 0) {
    limit = ` LIMIT ${pageCount} OFFSET ${pagelimit}`;
  }

  if ((sortColumn != '' && sortColumn != undefined) && (sortOrder != '' && sortOrder != undefined)) {
    orderby = ` ORDER BY "${sortColumn}" ${sortOrder}`;
  }

  if (filterValue != '' && filterValue != undefined) {
    filter = ` AND ("name" LIKE '%${filterValue}%' OR "emailId" LIKE '%${filterValue}%' ) `;
  }

  subQuery = ' JOIN master_catalog.user_roles AS b ON a."role" = b."roleId"';

  const finalQuery = `SELECT DISTINCT "userId", "name", "emailId", "role", "status", to_char("created_timestamp", 'YYYY-MM-DD') AS createddate, "modified_timestamp", "roleName" FROM master_catalog.user AS a ${subQuery} where "status" = 1 and "userId" != ${user_id} ${filter} ${orderby} ${limit} `;

  db.tx(t => t.batch([
    t.any(finalQuery),
    t.any(`SELECT COUNT(a."userId") FROM master_catalog.user as a ${subQuery} where "status" = 1 and "userId" != ${user_id} ${filter}`)
  ]))
    .then((dataUsers) => {
      const opt = {};
      opt.datas = dataUsers[0];
      opt.total_count = dataUsers[1][0].count;

      res.send(response.success('data refresh', opt));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Select all User Roles List
 */
function getAllUserRoles(req, res) {
  const finalQuery = 'SELECT DISTINCT "roleId", "roleName" FROM master_catalog.user_roles ORDER BY "roleName" ASC';

  db.query(finalQuery)
    .then((userRoles) => {
      res.send(response.success('data refresh', userRoles));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Add User details.
 */
function addUser(req, res) {
  const { user_name, user_email, user_role } = req.swagger.params.body.value;

  const defaultPassword = 'dsrc@123';
  const dt = new Date();
  db.none('INSERT INTO master_catalog.user("name", "emailId", "role", "password", "status", "created_timestamp") VALUES($1, $2, $3, $4, $5, $6)', [user_name, user_email, user_role, defaultPassword, 1, dt])
    .then(() => {
      const mailData = {};
      mailData.temName = 'user/RegisterUserTemplate';
      mailData.emailId = user_email;
      mailData.subject = 'Screener App - User Registration';

      mailData.UserName = user_name;
      mailData.LoginUsername = user_email;
      mailData.Password = defaultPassword;

      conf.sendEmail(mailData);

      res.send(response.success('User details has been inserted successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * Update User details.
 */
function updateUser(req, res) {
  const {
    user_name,
    user_email,
    user_role,
    user_id
  } = req.swagger.params.body.value;

  const dt = new Date();

  db.query('UPDATE master_catalog.user SET "name" = $1, "emailId" = $2, "role" = $3, "modified_timestamp" = $4 WHERE "userId" = $5', [user_name, user_email, user_role, dt, user_id])
    .then(() => {
      res.send(response.success('User details has been updated successfully.', []));
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * Delete User details.
 */
function deleteUser(req, res) {
  const user_id = req.swagger.params.user_id.value;
  let status = req.swagger.params.user_status.value;

  status = (status) || 0;

  db.query('UPDATE master_catalog.user SET "status" = $1 WHERE "userId" = $2', [status, user_id])
    .then(() => {
      if (status) {
        res.send(response.success('User data has been Reactivated Successfully.', []));
      } else {
        res.send(response.success('User data has been deleted successfully.', []));
      }
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * get User Data By Email details.
 */
function getUserDataByEmail(req, res) {
  const email_id = req.swagger.params.email_id.value;

  const finalQuery = `SELECT DISTINCT "userId", "name", "emailId", "role", "status" FROM master_catalog.user WHERE "emailId" = '${email_id}'`;

  db.query(finalQuery)
    .then((dataUser) => {
      const existObj = {};
      existObj.data = dataUser[0];
      const status = dataUser[0] ? 1 : 0;
      existObj.status = status;

      res.send(response.success('data refresh', existObj));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * get User Data By User Role
 */
function getUserDataByRole(req, res) {
  const user_role = req.swagger.params.user_role.value;
  const role_user = req.swagger.params.role_user.value;

  const roleUser = (role_user) ? `, ${role_user}` : '';

  const finalQuery = `SELECT DISTINCT "userId", "name", "emailId", "role", "status" FROM master_catalog.user WHERE "status" = 1 AND "role" IN(${user_role}${roleUser})`;

  db.query(finalQuery)
    .then((dataUserRole) => {
      const existObj = {};
      existObj.data = dataUserRole;
      const status = dataUserRole[0] ? 1 : 0;
      existObj.status = status;

      res.send(response.success('data refresh', existObj));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * get User Desginations
 */
function getDesignations(req, res) {
  const query = 'SELECT "designationId", "designationName" FROM master_catalog.resource_designation WHERE "designationStatus" = 1';

  db.query(query)
    .then((dataDesingation) => {
      const existObj = {};
      existObj.data = dataDesingation;
      const status = dataDesingation[0] ? 1 : 0;
      existObj.status = status;

      res.send(response.success('data refresh', existObj));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * get User from HRMS without assigned any projects.
 */
function getUnassignedUsers(req, res) {
  const empName = req.swagger.params.empname.value;

  let filter = '';
  let filter1 = '';
  if (empName) {
    filter = ` AND u.FirstName LIKE '%${empName}%' OR u.LastName LIKE '%${empName}%' `;
    filter1 = ` AND FirstName LIKE '%${empName}%' OR LastName LIKE '%${empName}%' `;
  }

  sql.close(config);
  // connect to your database
  sql.connect(config, (err) => {
    if (err) console.log(err);

    // create Request object
    const request = new sql.Request();

    request.query(`select EmailAddress, UserID AS clientId, EmpId, FirstName+' '+LastName as clientName from Users where isactive=1 ${filter1}
      Except
      select distinct u.EmailAddress, u.UserID, u.EmpId, u.FirstName+u.LastName as Names from userprojects as a
      join projects as b
      on a.ProjectID=b.ProjectID
      join users as u
      on u.UserID=a.UserID
      where a.IsActive=1 and b.IsActive=1 and u.IsActive=1 ${filter} `, (err, recordset) => {
      if (err) console.log(err);
      res.send(response.success('data refresh', recordset));
    });
  });
}
