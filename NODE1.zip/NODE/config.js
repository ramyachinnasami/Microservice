const convict = require('convict');

/*
 * NOTE on defaults:
 * According to Convict docs: "The philosophy was to have production values be the default values."
 */

const schema = Object.assign(
  {},
  require('./config/schema-base.js')
);

// Define a schema
const conf = convict(schema);

// Load environment dependent configuration
const env = conf.get('env');

conf.loadFile(`./config/environment/${env}.json`);

// Perform validation
conf.validate({ allowed: 'strict' });

module.exports = conf;
