const nodemailer = require('nodemailer');
const nunjucks = require('nunjucks');
const fs = require('fs');
const conf = require('./../../config');


/**
 * @name: sendEmail
 * @description :
 * get user details to send email
 *
 * @return {object} userData - user details
 */
exports.sendEmail = function (userData) {
  // Returns a Promise that will resolve once sendMail calls completed
  return new Promise(((resolve, reject) => {
    userData.LoginURL = conf.get('url').login_url;

    userData.emailActionURL = conf.get('url').email_direct_url;

    const templateName = `${process.cwd()}/templates/${userData.temName}.html`;
    // Reading the html template to send email to adopter
    const emailBody = this.renderTemplate(templateName, userData);

    // create reusable transporter object using the default SMTP transport
    const transporter = nodemailer.createTransport(conf.get('mailerConfig'));

    let emailId = [];
    emailId = userData.emailId;

    const mailOptions = {
      from: 'ramya.chinnasamy@dsrc.co.in', // sender address
      to: emailId, // list of receivers
      subject: userData.subject, // Subject line
      html: emailBody // HTML template
    };
    if (conf.get('status').emailSend == 1) {
      transporter.sendMail(mailOptions)
        .then((info) => {
          resolve(info);
        }).catch((err) => {
          reject(err);
        });
    }
  }));
};

/**
 * @name: validationErrorHandling
 *
 * @description
 * parameter validation error response
 *
 * @returns {Object} parameter validation error response
 */
exports.validationErrorHandling = function () {
  const parameterValidationError = {
    body: {
      errorResponse: {
        msg: 'Request validation failed: Parameter (body) failed validation'
      }
    }
  };
  return parameterValidationError;
};
