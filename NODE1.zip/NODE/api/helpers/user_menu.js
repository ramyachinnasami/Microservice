

exports.menuData = function () {
  return [
    {
      title: 'Dashboard',
      desc: 'dashboard content',
      root: true,
      icon: 'flaticon-line-graph',
      page: '/dashboard',
      roles: [1, 2, 3, 4]
    }
  ];
};
