

exports.routesData = function () {
  return [
    {
      path: '',
      redirectTo: '/dashboard',
      pathMatch: 'full'
    },
    {
      path: 'dashboard',
      component: 'DashboardComponent',
      roles: [1, 2, 3, 4]
    }
  ];
};
