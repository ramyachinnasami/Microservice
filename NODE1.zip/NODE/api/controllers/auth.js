const jwt = require('jsonwebtoken');
const util = require('util');
const _ = require('lodash');
const jwt_decode = require('jwt-decode');
const conf = require('../../config');
const response = require('../../config/response');
const sqlQueries = require('./../../config/queries/sqlQueries');
const menus = require('./../helpers/user_menu');
const routes = require('./../helpers/angular_routes');
const utilities = require('./../helpers/commonFunctions');


module.exports = {
  login,
  forgotPassword,
  getAllUserByInput,
  rootformation,
  userChangePassword
};

/**
 * login API and Authenticate user credentials, generate token
 * @param req a handle to the request object
 * @param res a handle to the response object
 * @returns Returning user's basic informations along with token id
 */
function login(req, res) {
  const { emailId, password } = req.swagger.params.body.value;
  db.query(sqlQueries.login.query, [emailId, password])
    .then((data) => {
      const userDetails = data[0];
      // console.info('inffppo', userDetails);
      // Validate user details
      if (!userDetails) {
        const err = new Error('Invalid Credentials');
         err.status = 'UnauthorizedError';
         err.message = 'Invalid Credentials'
         throw err;
        //res.send(response.error('Invalid Credentials'));
      }
      // Generate Token after validated user credientals
      userDetails.token = jwt.sign(userDetails, conf.get('jwt').secret, {
        expiresIn: '60m'
      });

      if (userDetails.role == 1 || userDetails.role == 2 || userDetails.role == 3 || userDetails.role == 4) {
        // Generate defalut page redirecti  on based on user role
        userDetails.indexComponent = {
          path: 'dashboard',
          component: 'DashboardComponent',
          url: '/dashboard'
        };
      } else if (userDetails.role == 0) {
        userDetails.indexComponent = {
          path: 'technicalstack',
          component: 'ViewTechnicalStackComponent',
          url: '/technicalstack'
        };
      }

      res.send(response.success('Login Successfully', userDetails));
    }).catch((err) => {
      if (err.status) res.error(err.status, err);
      else res.error(err);
    });
}

/**
 * @name: forgotPassword
 * @description :
 * Process to forgot the password and generate digest
 *
 * @return {object} body - user details
 */
function forgotPassword(req, res) {
  const body = req.swagger.params.body.value;
  db.func('master_catalog.forgot_password', [
    body.email
  ])
    .then((data) => {
      const result = data[0].forgot_password;
      const output = {};
      // calling send email functionality to send the reset password link to user

      const mailData = {};
      mailData.temName = 'user/ForgetPasswordTemplate';
      mailData.subject = 'Screener App - Forgot Password';
      mailData.emailId = result.emailId;

      mailData.UserName = result.name;
      mailData.Password = result.password;
      utilities.sendEmail(mailData);

      return res.json(response.success('Password sent to your Mail id Successfully.', [])); // Return the json
    }).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}


/**
 * @name: getAllUserByInput
 * @description : Get the All the user by input
 *
 * @return {object} user details
 */
function getAllUserByInput(req, res) {
  const username = req.query.user_name;
  
  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const userid = decoded.userId;

  db.query(`SELECT "userId","name" FROM master_catalog."user" where "userId" != ${userid} and ("role" = 2 or "role" = 4) and "name" ILIKE '%${username}%' ORDER BY "name" `)
    .then(userData => res.json(response.success('Success', userData))).catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

/**
 * @name: rootformation
 * @description : generate root and menu
 * @return json
 */
function rootformation(req, res) {
  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);
  const id = decoded.userId;
  db.one(sqlQueries.common.getrolebyid, [id])
    .then((data) => {
      const role = data.role;
      const resp = {
        menu: validateRoutes(JSON.parse(JSON.stringify(menus.menuData())), role),
        routes: validateRoutes(JSON.parse(JSON.stringify(routes.routesData())), role)
      };
      res.send(response.success('root success', resp));
    })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}

function validateRoutes(data, role) {
  if (data === null) {
    return;
  }
  validateChildRoutes(data, role);
  // removing all null value
  data = _.compact(data);
  // REMOVING NULL FROM THE SUB-MENU
  data.forEach((element, index) => {
    if (element.submenu != undefined) {
      data[index].submenu = _.compact(data[index].submenu);
    }
  });

  return data;
}

/**
 * @name: validateChildRoutes
 * @description : removing unwanted menu based on roll
 */
function validateChildRoutes(data, role) {
  data.forEach((element, index) => {
    // checking roles exist or not
    if ('roles' in element) {
      // checking for submenu
      if (element.submenu != undefined) {
        validateChildRoutes(data[index].submenu, role);
      }

      /* removing the object from the menu, if the the role is (not) in allowed roles  */
      if (element.roles.includes(role)) {
        delete data[index].roles;
      } else {
        delete data[index];
        // data.splice(index, 1);
      }
    }
  });
}


/**
 * @name: userChangePassword
 * @description : removing unwanted menu based on roll
 */
function userChangePassword(req, res) {
  const changePwd = req.swagger.params.body.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  const newpass = changePwd.newPassword;
  const user_id = decoded.userId;

  // const userSel = `select * from master_catalog."user" where "status" = 1 AND "userId" = '${user_id}' `;
  // const updatePwd = `update master_catalog."user" set "password" = '${newpass}' where "userId" = '${user_id}' `;

  db.query(sqlQueries.login.user, [user_id]).then((usrResult) => {
    if (usrResult.length > 0) {
      db.query(sqlQueries.login.updatePwd, [newpass, user_id]).then(() => {
        res.send(response.success('The password has been changed successfully', []));
      });
    } else {
      res.send(response.success('The password has not changed successfully', []));
    }
  })
    .catch((err) => {
      if (util.isError(err)) res.error('NotFoundError', err); // return 404
      else res.error('InternalServerError', err); // else 500
    });
}
