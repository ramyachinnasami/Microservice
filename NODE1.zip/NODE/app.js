/* eslint-disable no-useless-escape */

// var SwaggerRestify = require('swagger-restify-mw');
const SWAGGER_FILE = 'api/swagger/swagger.yaml'; // relative to appRoot
const CONTROLLER_PATH = 'api/controllers'; // relative to appRoot
const RESTIFY_METHODS = {
  DELETE: 'del',
  OPTIONS: 'opts'
};
const swaggerTools = require('swagger-tools');
const sway = require('sway');
const path = require('path');
const restify = require('restify');
const rjwt = require('restify-jwt-community');
const conf = require('./config.js');
const dbHelper = require('./config/dbconf/db');
// const dbMsSql = require('./config/dbconf/mssql');
const createLogger = require('./@sapp/logging');

// getting the configManager from conf and update the conf path based on he environment
// const configManager = conf.get('configManager');

const app = restify.createServer();
const logger = createLogger(conf.get('logging')).child({ role: 'server' });

app.use(restify.queryParser());
app.use(restify.bodyParser());


function corsHandler(req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, X-Response-Time, X-PINGOTHER, X-CSRF-Token,Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');
  res.setHeader('Access-Control-Expose-Headers', 'X-Api-Version, X-Request-Id, X-Response-Time');
  res.setHeader('Access-Control-Max-Age', '1000');
  return next();
}

function optionsRoute(req, res, next) {
  res.send(200);
  return next();
}

app.use(restify.CORS({
  credentials: true, // defaults to false
  methods: ['GET', 'DELETE', 'POST', 'PUT', 'OPTIONS']
}));

/*
routes and authentication handlers
*/

app.opts('/\.*/', corsHandler, optionsRoute);

// Exclude below request for token validation
app.use(rjwt(conf.get('jwt')).unless({
  path: [
    '/login',
    '/filedownload',
    '/forgotpassword',
    '/screener/docs/',
    '/screener/docs/swagger-ui.css',
    '/screener/docs/swagger-ui-bundle.js',
    '/docs/swagger-ui-standalone-preset.js',
    '/screener/docs/swagger-ui-standalone-preset.js',
    '/screener/docs/favicon-32x32.png',
    '/screener/docs/favicon-16x16.png',
    '/screener/docs/swagger.json',
    '/interviewaction'
  ]
}));

app.use(require('./@sapp/response')());
app.use(require('./@sapp/errors')()); // Adds res.error()
app.use(require('./@sapp/tracing')({ logger }));

global.env_configuration = conf.get('configManager');

dbHelper.initDBConnection()
  .then(() => sway.create({
    // Parse the swagger file into JSON
    definition: path.resolve(conf.get('appRoot'), SWAGGER_FILE)
  }))
  .then(api => setImmediate(() => {
    // setImmediate is to break this callback out of the
    // Promise's try/catch, so that thrown errors during
    // init *do* crash the app.
    //
    // We want to crash the app during init so we know as
    // soon as possible what happened, and the stack trace
    // is preserved.

    // Validate Swagger document before continuing
    api.validate().errors.forEach((err) => {
      throw new SyntaxError(JSON.stringify(err, null, 4));
    });

    // Initialize the Swagger middleware
    swaggerTools.initializeMiddleware(api.definition, (middleware) => {
      const port = conf.get('port');

      // swagger-ui integration (there is a bug that forces us to use root)
      app.use(middleware.swaggerUi({
        swaggerUi: '/myapp/docs/',
        apiDocs: '/myapp/docs/swagger.json'
      }));

      // Map Restify's methods to swagger-tools router methods
      Object.keys(app.router.routes)
        .map(r => RESTIFY_METHODS[r] || r)
        .map(r => r.toLowerCase())
        .forEach((r) => {
          app[r](
            '.*',
            middleware.swaggerMetadata(),
            middleware.swaggerValidator(),
            middleware.swaggerRouter({
              controllers: path.resolve(conf.get('appRoot'), CONTROLLER_PATH)
            }),
            (req, res) => res.error('NotFoundError')
          );
        });

      // Listen here (and not earlier) because we want initialization errors to crash the app.
      process.on('uncaughtException', (err) => {
        logger.error(err);
        // console.info('errror', err);
      });

      app.listen(port);
      console.log('Auth service is up and running on port', port);
    });
  }));

module.exports = app; // for testing
