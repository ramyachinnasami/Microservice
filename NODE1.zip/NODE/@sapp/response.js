

const util = require('util');

function setMeta(meta) {
  Object.assign(this._meta, meta);
}

function sendWithMeta(statusCode, body = {}) {
  const req = this.req;
  const res = this;

  res.setMeta({
    resource: req.url,
    version: req.swagger.swaggerObject.info.version,
    time: `${Date.now() - req.time()}ms`
  });

  const output = {
    meta: res._meta,
    body
  };

  res.json(statusCode, output);
}

module.exports = () => function respondWithMetaHelper(req, res, next) {
  res._meta = {};
  res.setMeta = setMeta;
  res.sendWithMeta = sendWithMeta;
  next();
};
