

const errors = require('restify-errors');

function sendRestifyError(type, message, details) {
  // In the case of res.error(Error)
  if (typeof type !== 'string') {
    message = type;
    type = 'InternalError';
  }

  // In the case of res.error('...', Error)
  if (message instanceof Error) {
    message = message.message;
    details = message.details;
  }

  const E = errors[type] || errors.InternalError;


  const err = new E(message || 'No further information');

  if (details) err.body.details = details;

  this.send(err);

  if (this.log) this.log.error(String(err));
}

// Take an error response and relay it to the current response
function relayResponseError(res, service) {
  const {
    body, path,
    statusCode = 500
  } = res;


  const message = body.message || 'No further information';


  const err = errors.codeToHttpError(statusCode, message);

  // To trace which microservice originated this error
  if (service) err.body.details = { service };

  this.send(err);
}

module.exports = () => function responseError(req, res, next) {
  res.error = sendRestifyError;
  res.relayResponseError = relayResponseError;

  next();
};
