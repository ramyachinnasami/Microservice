

function onResFinished(err) {
  this.removeListener('finish', onResFinished);
  this.removeListener('error', onResFinished);

  const log = this.log;

  if (err) {
    log.trace({
      res: this,
      err,
      direction: 'send'
    }, err.message || 'request errored');

    return;
  }

  log.trace({ res: this, direction: 'send' }, 'response sent');
}

function onReqAborted() {
  const res = this.res;
  res.statusCode = 408;
  onResFinished.call(res, new Error('request aborted'));
}


module.exports = ({ logger }) => function tracingMiddleware(req, res, next) {
  // Methods like `req.id` gets filtered by the logger, so
  // our formatters can't call it. So we cache it here.
  req.log = res.log = logger.child({ req, role: 'server', reqId: req.id() });

  res.on('finish', onResFinished);
  res.on('error', onResFinished);
  req.once('aborted', onReqAborted);

  req.log.trace({ direction: 'receive' }, 'request received');

  next();
};
