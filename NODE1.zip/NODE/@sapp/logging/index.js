/* global module:true, require:true */


const _ = require('lodash');


const fs = require('fs');


const path = require('path');


const pino = require('pino');


const template = _.template;

// To follow Logstash syntax...
_.templateSettings.interpolate = _.templateSettings.evaluate = /%{([\s\S]+?)}/g;
_.templateSettings.escape = /%{-([\s\S]+?)}/g;

const TRANSPORT_NAMES = {
  file: createFileTransport,
  stdout: createStdoutTransport
};


/*
 * Tables for determining the type of message.
 *
 * These types are derived from Twitter Zipkin
 */
function messageType(role, direction) {
  let type;

  switch (`${role}:${direction}`) {
    case 'server:receive':
      type = 'sr';
      break;

    case 'server:send':
      type = 'ss';
      break;

    case 'client:receive':
      type = 'cr';
      break;

    case 'client:send':
      type = 'cs';
      break;
  }

  return type;
}

function createFileTransport(config) {
  const logDir = config.dir || path.join(process.cwd(), 'logs');


  const logFile = path.join(logDir, Date.now());

  // Create log directory if it doesnt exist
  if (!fs.existsSync(logDir)) fs.mkdirSync(logDir);

  return fs.createWriteStream(logFile);
}

function createStdoutTransport(config) {
  return process.stdout;
}

/*
 * configure and start logging
 * @param {Object} config The configuration object for defining dir: log directory, level: loglevel
 * @return the created logger instance
 */
function createLogger(config, formatterType = 'restify') { // Default to the restify formatter
  let transport = TRANSPORT_NAMES[config.transport](config);
  const createFormatter = require(`./formatters/${formatterType}`);

  if (config.format) {
    const pretty = pino.pretty({
      formatter: createFormatter(template(config.format), messageType)
    });

    pretty.pipe(transport);
    transport = pretty;
  }

  const logger = pino({
    name: config.name,
    level: config.level,
    serializers: pino.stdSerializers
  }, transport);

  return logger;
}

module.exports = createLogger;
