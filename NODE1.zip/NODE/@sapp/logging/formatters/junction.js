

const LABELS = require('pino').levels.labels;

module.exports = (template, messageType) => (log) => {
  // `parentRequest` is the restify incoming http request
  const parentRequest = log.req;


  const locator = log.locator || {};


  const payload = log.payload || {};

  // template returning the constructed logging format
  return template({
    time: log.time,
    name: log.name,
    hostname: log.hostname,
    level: String(LABELS[log.level]).toUpperCase(),
    role: log.role,
    type: messageType(log.role, log.event),

    url: payload.path || locator.path,
    method: locator.method,
    statusCode: (log.event === 'receive') ? log.payload.statusCode : null,

    correlation: parentRequest && parentRequest.headers['x-correlation-id'],
    parent: log.parentRequestId,
    id: log.ticket,

    msg: ''
  });
};
