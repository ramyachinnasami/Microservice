This directory contains test-generated files. They are added to the .gitignore
