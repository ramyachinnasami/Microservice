module.exports = {
  login: {
    query: 'SELECT "emailId", "name", "userId", "role", "userTeam" FROM master_catalog.user WHERE "status" > 0 AND LOWER("emailId") = LOWER($1) and "password" = $2',
    user: 'select * from master_catalog."user" where "status" = 1 AND "userId" = $1',
    updatePwd: 'update master_catalog."user" set "password" = $1 where "userId" = $2'
  },
  technicalstack: {
    validate: {
      add: 'SELECT "stackName" FROM master_catalog.technical_stack WHERE "stackName" = $1 AND "status" = 1',
      edit: 'SELECT "stackName" FROM master_catalog.technical_stack WHERE "status" = 1 AND "stackName" = $1 and "stackId" != $2'
    },
    select: 'SELECT DISTINCT "stackId", "stackName" FROM master_catalog.technical_stack where "status" = 1',
    insert: 'INSERT INTO master_catalog.technical_stack("stackName", "status")VALUES ($1, 1)',
    update: 'UPDATE master_catalog.technical_stack SET "stackName"=$1 WHERE "stackId" = $2',
    delete: 'UPDATE master_catalog.technical_stack SET "status"= 0 WHERE "stackId" = $1',
    count: 'SELECT COUNT("stackId") FROM master_catalog.technical_stack where "status" = 1'
  },
  common: {
    getrolebyid: 'SELECT "role" FROM master_catalog."user" where "userId"=$1'
  },
  candidateInfo: {
    candidatesBasedOnType: 'SELECT DISTINCT a."candidateId", concat(a."candidateFirstName",\' \',a."candidateLastName") AS candidatefullname, a."candidateFirstName", a."candidateEmailId", a."candidateMobileNo", a."workExpYears", a."workExpMonths", to_char(b."scheduleDate", \'DD-MM-YYYY\') AS scheduledate, TO_CHAR(b."scheduleFromTime",\'hh:mi AM\') AS schedulefromtime, TO_CHAR(b."scheduleToTime",\'hh:mi AM\') AS scheduletotime, c."name" as lastInterviewedBy, d."designationName" as appliedFor FROM candidate_catalog.candidate_details as a LEFT JOIN interview_catalog.schedule_interview AS b ON a."candidateId" = b."candidateId" LEFT JOIN master_catalog.user AS c ON c."userId" = a."candidateAcceptBy" LEFT JOIN master_catalog.resource_designation AS d ON a."resourceType" = d."designationId"'
  },
  dashboard: {
    counts: {
      candidateAcceptedByInterviewerCount: 'select count("candidateId") as acceptedbyinterviewer FROM candidate_catalog.candidate_details where "status" = 1 AND "candidateAcceptStatus" = 1 AND "candidateAcceptBy" = $1',
      yetToAcceptCount: 'select count(a."scheduleId") as yettoaccept FROM interview_catalog.schedule_interview AS a JOIN candidate_catalog.candidate_details AS b ON a."candidateId" = b."candidateId" where "candidateAcceptStatus" = 0 and ($1 = ANY (string_to_array("interviewer",\',\')))',
      pendingCount: 'select count(a."scheduleId") as pendingcount FROM interview_catalog.schedule_interview AS a JOIN candidate_catalog.candidate_details AS b ON a."candidateId" = b."candidateId" where "candidateAcceptStatus" = 0 and "interviewer" = \'\'',
      weeklyScheduledCount: 'SELECT count("scheduleDate") as weeklyschedule FROM interview_catalog.schedule_interview WHERE ($1 = ANY (string_to_array("interviewer",\',\'))) and "scheduleDate" >= (current_date - interval \'7\' DAY) and "scheduleDate" <= (current_date) and "status" = 1'
    }
  },
  interviewSchedule: {
    toGetGenQues: 'select a."questionId", a."comments", a."ratings", a."questionType", b."question" FROM interview_catalog.interview_history as a  LEFT JOIN interview_catalog.interview_questions as b ON a."questionId" = b."questionId" where a."questionType" = \'general\' and a."candidateId"= $1'
  }
};
