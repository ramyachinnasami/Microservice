const sql = require('mssql');

const dbConfig = {
	user: 'HRMS_Dev',
	password: 'hrm5$dev123',
	server: 'DSRCWIN2016\\SQLEXPRESS2017',
	database: 'HRMS_Dev'
};

var connection = sql.connect(dbConfig, function (err) {
    if (err)
        throw err;
});

module.exports = connection;