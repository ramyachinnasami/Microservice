/* ********************************************************************************************
** File: 05-forgot_password.sql
** Name: auth.forgot_password(varchar)
** Desc: To forgot password and generate digest for the email
** Auth: Screener-APP
** Date Created: Jan 28, 2019
** Date Updated:
* ********************************************************************************************/

-- DROP FUNCTION master_catalog.forgot_password(varchar);

CREATE OR REPLACE FUNCTION master_catalog.forgot_password(
    IN varchar(100)	-- email
)

RETURNS SETOF json
AS $BODY$

DECLARE
_email 		ALIAS FOR $1;
json_result TEXT;
_email_date character varying(100):= CONCAT(_email,current_date);
_digest character varying(50):= substring(md5('screener app'||_email_date) from 0 for 32);

BEGIN

/* lowercase email to reflect email_users table behavior */
_email := lower(_email);

IF EXISTS(
		SELECT "emailId" 
		FROM master_catalog.user
		WHERE "emailId" = _email
) THEN
	UPDATE master_catalog.user
	SET forgot_password_digest = _digest,
	forgot_password_digest_exp_ts = (now()+ interval '24 hours'),
	modified_timestamp = now()
	WHERE "emailId" = _email;	
ELSE
    RAISE EXCEPTION 'Provided email address does not exists on master.user table... email:%', _email;
END IF;

json_result :=
'SELECT to_json(t)
FROM (
	SELECT 
		"emailId",
		"userId",
		"name",
        "forgot_password_digest" as "forgotPassword",
	extract (epoch from forgot_password_digest_exp_ts) as "modifiedDate"
	FROM master_catalog.user
	WHERE "emailId" = '''|| _email ||'''
) t';

RETURN QUERY EXECUTE json_result;

END;
$BODY$

LANGUAGE plpgsql
SECURITY DEFINER;