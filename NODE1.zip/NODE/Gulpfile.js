const path = require('path');
const gulp = require('gulp');
const file = require('gulp-file');
const conflict = require('gulp-conflict');
const sway = require('sway');
//const testGen = require('@aap/swagger-test-templates').testGen;
const testGen = require('./@sapp/swagger-test-templates').testGen;

gulp.task('tests', (done) => {
  const testsLocation = path.join(process.cwd(), 'test', 'api', 'client');
  const testGenOpts = {
    assertionFormat: 'should',
    testModule: 'supertest',
    pathName: [],
    allowNull: true
  };

  sway.create({ definition: path.join(process.cwd(), 'api', 'swagger', 'swagger.yaml') })
    .then(({ definition }) => {
      const tests = testGen(definition, testGenOpts).map(({
        name, test
      }) => ({ name, source: test }));

      file(tests, { src: true })
        .pipe(conflict(testsLocation))
        .pipe(gulp.dest(testsLocation))
        .on('end', done);
    });
});

